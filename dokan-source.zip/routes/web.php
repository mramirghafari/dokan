<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();

//logout
Route::get('/logout', function () {
    \Auth::logout();
    return redirect()->route('login');
});

Route::post('/sendSmsLogin', [\App\Http\Controllers\Auth\SMSController::class, 'index'])->name('sendSmsLogin');
Route::get('/otp', [\App\Http\Controllers\Auth\SMSController::class, 'otp'])->name('userOTP');
Route::post('/vilidation_code', [\App\Http\Controllers\Auth\SMSController::class, 'vilidation_code'])->name('vilidationCode');

Route::middleware(['auth'])->group(function () {
    //index
    Route::get('/', "HomeController@index")->name('index');
    Route::get('/dashboard/org-data/{id}', "HomeController@getOrgData")->name('getOrgData');

    //Change password
    Route::get('/profile', "UserController@profile")->name('profile.index');
    Route::post('/profile', "UserController@profileUpdate")->name('profile.update');

    //Notify Limit
    Route::post('/products/notify/{product}', "ProductController@notify")->name('product.notify');


    //Roles
    Route::resource('roles', RoleController::class)->except('create', 'show', 'destroy');
    //Permissions
    Route::resource('permissions', PermissionController::class)->except('create', 'show', 'destroy');
    //Brands
    Route::resource('brands', BrandController::class)->except('create', 'show', 'destroy');
    //Units
    Route::resource('units', UnitController::class)->except('create', 'show', 'destroy');
    Route::get('/units/getParent/{id}', "UnitController@parents")->name('units.parent');
    //Organizations
    Route::resource('organizations', OrganizationController::class)->except('create', 'show');
    //Cities
    Route::resource('cities', CityController::class)->except('create', 'show');
    //Regions
    Route::resource('regions', RegionController::class)->except('create', 'show');
    Route::get('region/{region_id}/areasList', "RegionController@areasList")->name('regions.areasList');
    Route::get('region/{region_id}/CustomersList', "RegionController@CustomersList")->name('regions.CustomersList');
    Route::get('region/{region_id}/activeCustomersList', "RegionController@activeCustomersList")->name('regions.activeCustomersList');
    Route::get('region/{region_id}/invoiceList', "RegionController@invoiceList")->name('regions.invoiceList');
    //Areas
    Route::resource('areas', AreaController::class)->except('create', 'show');
    Route::get('areas/{area_id}/customersList', "AreaController@customersList")->name('areas.customersList');
    Route::get('areas/{area_id}/activeCustomersList', "AreaController@activeCustomersList")->name('areas.activeCustomersList');
    Route::get('areas/{area_id}/invoiceList', "AreaController@invoiceList")->name('areas.invoiceList');
    Route::get('getAreasByRegion/{region_id}', "AreaController@getAreasByRegion")->name('regions.getAreasByRegion');
    //Stores
    Route::resource('stores', StoreController::class)->except('create', 'show', 'destroy');
    // Material Stores
    Route::resource('MaterialStores', MaterialStoreController::class)->except('create', 'show');
    // Material
    Route::resource('Materials', MaterialController::class);
    //Categories
    Route::resource('categories', CategoryController::class)->except('create', 'show', 'destroy');
    //Products
    Route::resource('products', ProductController::class)->except('show');
    Route::get('products/trashed', "ProductController@trashGet")->name('products.trashed.get');
    Route::delete('/products/trashed/{product}', "ProductController@trashPost")->name('products.trashed.post');
    Route::post('/products/restore/{product}', "ProductController@restore")->name('products.restore');
    Route::get('/products/getCategory/{id}', "ProductController@getCategory")->name('products.category.get');
    Route::get('/products/getprs/{id}', "ProductController@getprs")->name('products.getprs.get');
    Route::get('/products/getprInfo/{id}', "ProductController@getprInfo")->name('products.getprInfo');
    Route::get('/products/getStore/{id}', "ProductController@getStore")->name('products.store.get');
    Route::get('/products/neworder', "ProductController@neworder")->name('products.neworder');
    Route::get('/products/collection', "ProductController@collection")->name('products.collection');
    Route::get('/products/update-fees', "ProductController@updateFees")->name('products.updateFees');
    Route::post('/update_product_fees', "ProductController@update_product_fees")->name('products.update_product_fees');
    Route::get('productsByStore/{store?}', "ProductController@productsByStore")->name('products.productsByStore');

    //Customers
    Route::resource('customers', CustomersController::class);
    Route::any('customers_search', "CustomersController@search")->name('customers.search');
    Route::delete('customers/destory/{customer_id}', "CustomersController@destroy")->name('customers.destroy');
    Route::get('customers/{customer_id}/orders', "CustomersController@CustomerOrders")->name('customers.orders');
    Route::get('customersCreatedByMe', "CustomersController@createdByMe")->name('customers.createdByMe');
    Route::get('activeCustomers', "CustomersController@activeCustomers")->name('customers.activeCustomers');
    Route::get('customers/trashed', "CustomersController@trashGet")->name('customers.trashed.get');
    Route::delete('/customers/trashed/{product}', "CustomersController@trashPost")->name('customers.trashed.post');
    Route::post('/customers/restore/{product}', "CustomersController@restore")->name('customers.restore');
    Route::post('/update_customer_loc/{Customer}', "CustomersController@update_customer_loc")->name('update_customer_loc');
    Route::post('/update_customer_info_by_visitor/{Customer}', "CustomersController@update_customer_info_by_visitor")->name('update_customer_info_by_visitor');

    //Tasks
    Route::resource('tasks', TasksController::class);
    Route::get('getVisitorsByRegion/{region_id}', "TasksController@getVisitorsByRegion")->name('tasks.getVisitorsByRegion');
    Route::get('/active_tasks', "TasksController@active_list")->name('tasks.active_list');
    Route::get('/MyTaks/{task}', "TasksController@MyTask")->name('tasks.visitor_list');
    Route::get('/CustomerInfo/{Customer}/MyTaks/{task?}', "CustomersController@show")->name('tasks.CustomerInfo');
    Route::get('/MyTasks', "TasksController@MyTasks")->name('tasks.MyTasks');

    //Targets
    Route::resource('targets', TargetController::class);
    Route::get('/MyTargets', "TargetController@MyTargets")->name('targets.MyTargets');
    Route::get('targetsHistory', "TargetController@history")->name('targets.history');
    //Histories
    //Route::get('/histories', "HistoryController@index"::class)->name('history.index');

    //Employees
    Route::resource('employees', EmployeeController::class)->except('create', 'show', 'destroy');
    Route::get('/employees/getUnit/{id}', "EmployeeController@getUnit")->name('employees.unit');
    Route::get('/employees/getChildUnit/{id}', "EmployeeController@getChildUnit")->name('employees.childUnit');
    //users
    Route::patch('users/{user}/update', "UserController@updateU")->name('users.update');
    Route::resource('users', UserController::class)->except('create', 'show', 'update');
    Route::any('/user/{user}/invoices', "UserController@userInvoiceList")->name('userInvoiceList');

    //Deliveries
    Route::resource('deliveries', DeliveryController::class)->except('show');
    Route::get('/deliveries/getEmployee/{id}', "DeliveryController@getEmployee")->name('deliveries.employees');
    Route::get('/deliveries/active_invoices', "DeliveryController@active_list")->name('deliveries.active_list');
    Route::get('/deliveries/compeleted_invoices', "DeliveryController@compeleted")->name('deliveries.compeleted');
    Route::get('/deliveries/Outgoing', "DeliveryController@Outgoing")->name('deliveries.Outgoing');
    Route::post('/deliveries/OutgoingFilter', "DeliveryController@Outgoing")->name('deliveries.OutgoingFilter');
    Route::get('/deliveries/preOrderOutput', "DeliveryController@preOrderOutput")->name('deliveries.preOrderOutput');
    Route::post('/deliveries/preOrderOutputFilter', "DeliveryController@preOrderOutput")->name('deliveries.preOrderOutputFilter');
    Route::get('/deliveries/Outgoing_by_items', "DeliveryController@Outgoing_by_items")->name('deliveries.Outgoing_by_items');
    Route::post('/deliveries/Outgoing_by_items_Filter', "DeliveryController@Outgoing_by_items")->name('deliveries.Outgoing_by_items_Filter');
    Route::get('/deliveries/dayOrders', "DeliveryController@dayOrders")->name('deliveries.dayOrders');
    Route::get('/deliveries/addShipment', "DeliveryController@addShipment")->name('deliveries.addShipment');
    Route::get('/deliveries/shipments', "DeliveryController@shipments")->name('deliveries.shipments');
    Route::post('/deliveries/storeShipments', "DeliveryController@storeShipments")->name('deliveries.storeShipments');
    Route::get('/deliveries/EditShipment/{shipment}', "DeliveryController@EditShipment")->name('deliveries.EditShipment');
    Route::get('/deliveries/myShipment/{shipment}', "DeliveryController@myShipment")->name('deliveries.myShipment');
    Route::get('/deliveries/shipmentRoute/{factor}', "DeliveryController@shipmentRoute")->name('deliveries.shipmentRoute');

    //Tenants
    Route::resource('tenants', TenantsController::class);


    //Drivers
    Route::resource('freight', DriverController::class);
    Route::get('/freight/{Factor}', "DriverController@show")->name('customer_details');
    Route::post('/freight/update_by_driver/{Factor}', "DriverController@update_by_driver")->name('update_by_driver');

    //Accounts & Accounting
    Route::resource('Account', AccountController::class)->except('show');
    Route::resource('Terminals', TerminalController::class)->except('show');
    Route::resource('Accounting', AccountingController::class)->except('show');
    Route::get('AccountingFund', "AccountingController@index")->name('Accounting.index');
    Route::any('AccountingReviews', "AccountingController@AccountingReviews")->name('Accounting.AccountingReviews');
    Route::any('Accounting/ProductsSales', "AccountingController@ProductsSales")->name('Accounting.ProductsSales');
    Route::get('Accounting/payed', "AccountingController@payed")->name('Accounting.payed');
    Route::get('Accounting/unpayed', "AccountingController@unpayed")->name('Accounting.unpayed');
    Route::get('Accounting/cashpay', "AccountingController@cashpay")->name('Accounting.cashpay');
    Route::get('Accounting/checkpay', "AccountingController@checkpay")->name('Accounting.checkpay');
    Route::get('Accounting/unknown', "AccountingController@unknown")->name('Accounting.unknown');
    Route::post('Accounting/PrFilter', "AccountingController@PrFilter")->name('Accounting.PrFilter');
    Route::post('Accounting/Filter', "AccountingController@Filter")->name('Accounting.Filter');

    //AccountingReviews
    Route::resource('invoices', InvoiceController::class);
    Route::get('invoices/details', "InvoiceController@detailList")->name('details.list');
    Route::post('invoices/actions', "InvoiceController@actions")->name('invoices.actions');

    //Details For Invoice
    Route::delete('/invoices/detail/{detail}', "InvoiceController@deleteDetail")->name('invoices.detail.delete');
    Route::get('/details', "InvoiceController@detailList")->name('invoices.detail.list');
    Route::get('/invoices/detail/{detail}/edit', "InvoiceController@editDetail")->name('invoices.detail.edit');
    Route::patch('/invoices/detail/{detail}/edit', "InvoiceController@updateDetail")->name('invoices.detail.update');
    Route::get('/invoices/detail/{invoice}/create', "InvoiceController@addDetailGet")->name('detail.add.get');
    Route::post('/invoices/detail/{invoice}/create', "InvoiceController@addDetailPost")->name('detail.add.post');

    Route::get('/all_invoices', "InvoiceController@all_invoices")->name('invoices.all_invoices');
    Route::get('/active_invoices', "InvoiceController@active_list")->name('invoices.active_list');
    Route::get('/denciled_invoices', "InvoiceController@denciled")->name('invoices.denciled');
    Route::get('/compeleted_invoices', "InvoiceController@compeleted")->name('invoices.compeleted');
    Route::get('/assigned_to_drivers', "DeliveryController@assigned_to_drivers")->name('invoices.assigned_to_drivers');
    Route::get('/factor_reporter', "InvoiceController@factor_reporter")->name('invoices.reporter');
    Route::get('/myInvoices', "InvoiceController@myInvoices")->name('invoices.myInvoices');
    Route::get('/factor_deposit/{$factor}', "InvoiceController@factor_deposit")->name('invoices.depost');
    //Suppliers
    Route::resource('suppliers', SupplierController::class);

    //Stocks
    Route::resource('stocks', StockController::class)->except('show');
    Route::get('/need-entity', "StockController@need_entity")->name('stocks.need_entity');
    Route::get('/stocks-entrance', "StockController@entrance")->name('stocks.entrance');
    Route::get('/stocks/{store}/products', "StockController@storeProducts")->name('stocks.storeProducts');
    Route::get('/stocks/{store}/product/{product}', "StockController@storeProductCartex")->name('stocks.storeProductCardex');
    Route::get('/stocks/cartexStore', "StockController@store_cartex")->name('stocks.store_cartex');
    Route::get('/stocks/StoreProducts/{store}', "StockController@storeProducts")->name('stocks.StoreProductsCartex');
    Route::get('/stocks/cartex', "StockController@PrCartexList")->name('stocks.PrCartexList');
    Route::get('/stocks/cartex/{product}', "StockController@PrCartex")->name('stocks.PrCartex');
    Route::get('/stocks/getEmployee/{id}', "StockController@getEmployee")->name('stocks.employees');
    Route::get('/stocks/getCategory/{id}', "StockController@getCategory")->name('stocks.category.get');
    Route::get('/stocks/getStore/{id}', "StockController@getStore")->name('stocks.store.get');
    Route::get('/ProductionByExtraction', "StockController@ProductionByExtraction")->name('stocks.ProductionByExtraction');
    Route::post('/ProductionByExtractionProcess', "StockController@ProductionByExtractionProcess")->name('stocks.ProductionByExtractionProcess');
    Route::get('/ProductStock/{product}', "StockController@ProductStock")->name('stocks.ProductStock');
    //

    // import stock
    Route::get('/import-stock', "StockController@import_stock")->name('stocks.import_stock');
    Route::get('/stocks/{store}/productsTransfer', "StockController@storeProductsForTransfer")->name('stocks.storeProductsForTransfer');

    // Stock Transfer
    Route::get('/stock-transfer', "StockController@StockTransfer")->name('stocks.entrance_transfer');

    //Receipts
    Route::resource('receipt', ReceiptController::class);
    Route::post('receipt/storeTransfer', "ReceiptController@storeTransfer")->name('receipt.storeTransfer');
    Route::get('/stocks/{store}/receipts', "ReceiptController@storeReceipts")->name('stocks.storeReceipts');
    Route::get('/stocks/{store}/receipts/{receipt}', "ReceiptController@storeReceiptShow")->name('stocks.storeReceiptShow');
    Route::get('/deleteReceipt/{receipt}', "ReceiptController@deleteReceipt")->name('stocks.deleteReceipt');
    Route::post('/importReceiptAi', "ReceiptController@importReceiptAi")->name('stocks.importReceiptAi');


    // stock transfer

    //Abortions - کالاهای اسقاطی
    Route::resource('abortions', AbortionController::class)->except('show');

    //logs
    Route::get('/logs', "LogController@index")->name('logs.index');

    //Reports
    Route::get('/reports/deliveris', "ReportController@deliveries")->name('reports.deliveries.index');

    //Transfers
    Route::resource('transfers', TransferController::class)->except('show');
    Route::post('transfers/approved/{transfer}', "TransferController@approved")->name('transfers.approved');
    Route::post('transfers/read/{transfer}', "TransferController@read")->name('transfers.read');
    Route::get('transfers/add-product/{transfer}', "TransferController@addProduct")->name('transfers.add.product');
    Route::patch('transfers/add-product/{transfer}', "TransferController@storeProduct")->name('transfers.store.product');
    Route::get('transfers/product/deny/{transfer}', "TransferController@denyTransfer")->name('transfers.deny');

    //Stocks
    Route::resource('repairs', RepairController::class)->except('show');
    Route::get('/repairs/getEmployee/{id}', "RepairController@getEmployee")->name('repairs.employees');
    Route::get('/repairs/getCategory/{id}', "RepairController@getCategory")->name('repairs.category.get');
    Route::get('/repairs/getStore/{id}', "RepairController@getStore")->name('repairs.store.get');

    //CHANGE INFO
    Route::get('/change-info', "HomeController@changeInfoGet")->name('profile.change.get');
    Route::post('/change-info', "HomeController@changeInfoPost")->name('profile.change.post');

    //CHANGE SETTINGS
    Route::get('/settings', "SettingController@index")->name('settings.index');
    Route::post('/settings', "SettingController@update")->name('settings.update');

    //WAREHOUSE REPORTSS
    Route::get('/reports/warehouse', "ReportController@warehouse")->name('warehouse.index');
    Route::get('/reports/warehouse/filter', "ReportController@warehouseFilter")->name('warehouse.filter');
});

Route::post('/database/seeder', "InstallerController@index")->name('databaseSeeder');

Route::post('/add_factor_visitor', "InvoiceController@add_factor_visitor")->name('add_factor_visitor');
Route::get('/pishFactorInfo/{PishFactor}', "InvoiceController@pishFactorInfo")->name('pishFactorInfo');
Route::get('/pishFactorView/{PishFactor}', "InvoiceController@pishFactorInfo")->name('pishFactorView');
Route::post('/pishFactorUpdate/{PishFactor}', "InvoiceController@pishFactorUpdate")->name('pishFactorUpdate');
Route::get('/EditFactor/{PishFactor}', "InvoiceController@EditFactor")->name('EditFactor');
Route::post('/UpdateFactorItems/{PishFactor}', "InvoiceController@UpdateFactorItems")->name('UpdateFactorItems');
Route::post('/deletePF/{PishFactor}', "InvoiceController@DeleteFactor")->name('pishfactor.destroy');
Route::get('/waiting-orders', "InvoiceController@waiting_orders")->name('waiting_orders');
Route::get('/history-orders', "InvoiceController@history_orders")->name('history_orders');

// Depots
Route::resource('depot', DepotController::class);
Route::get('/history-orders', "InvoiceController@history_orders")->name('history_orders');

// Factor Setting
Route::resource('FactorManager', FactorSettingController::class);


Route::get('/update_costomers_user', function () {

    $userID = auth()->user()->id;
    $Logs = DB::table('logs')->where('user_id', $userID)->get();
    foreach ($Logs as $log) {
        if (str_starts_with($log->description, "یک مشتری ایجاد شد-")) {

            $infos = explode("-", $log->description);
            echo $infos[1] . "<br />";
        }
    }

    //dd($Logs);
    //$Customers = DB::table('customers')->where('role_id', $role->id)->pluck('store_id');

});


Route::get('/update_recive_times', function () {

    $userID = auth()->user()->id;
    $Logs = DB::table('pishfactors')->get();
    foreach ($Logs as $log) {
        if ($log->recive_date != null) {
            $jalali = explode("/", $log->recive_date);
            $miladi = Verta::jalaliToGregorian($jalali[0], $jalali[1], $jalali[2]);
            $ym = $miladi[0];
            if (strlen($miladi[1]) == 1) {
                $mm = "0" . $miladi[1];
            } else {
                $mm = $miladi[1];
            };
            if (strlen($miladi[2]) == 1) {
                $dm = "0" . $miladi[2];
            } else {
                $dm = $miladi[2];
            };
            echo $log->recive_date . " - $ym-$mm-$dm <br />";

            DB::table('pishfactors')->where('id', $log->id)->update(array(
                'recive_date_en' => "$ym-$mm-$dm 00:00:00",
            ));
        }
    }

    //dd($Logs);
    //$Customers = DB::table('customers')->where('role_id', $role->id)->pluck('store_id');

});

Route::get('/update_factor_items', function () {

    $userID = auth()->user()->id;
    $Logs = DB::table('pish_factor_items')->get();
    foreach ($Logs as $log) {

        $Product = DB::table('products')->where('id', $log->pr_id)->first();
        DB::table('pish_factor_items')->where('id', $log->id)->update(array(
            'price' => "$Product->price",
        ));
    }
});

Route::get('/add_first_depots', function () {

    $userID = auth()->user()->id;
    $Logs = DB::table('products')->get();
    foreach ($Logs as $log) {

        $InsertDepot = DB::table('depots')
            ->insert([
                'pr_id' => $log->id,
                'price' => $log->price,
                'entity' => $log->entity,
                'orderLimit' => $log->orderLimit,
                'discount' => $log->discount,
                'tax' => $log->tax,
                'fee_masraf' => $log->tax
            ]);



        $Selecte_Depot = DB::table('depots')->where('pr_id', $log->id)->first();


        DB::table('products')->where('id', $log->id)->update(array(
            'depot_id' => "$Selecte_Depot->id",
        ));
    }
});


Route::get('/update_area_region_city', function () {

    $userID = auth()->user()->id;
    $Logs = DB::table('pishfactors')->get();
    foreach ($Logs as $log) {
        $Customer = DB::table('customers')->where('id', $log->customer_id)->first();
        if ($Customer && $Customer->area != null) {
            $Area = DB::table('areas')->where('id', $Customer->area)->first();
            $Region = DB::table('regions')->where('id', $Area->region_id)->first();
            $City = DB::table('regions')->where('id', $Region->city_id)->first();
            DB::table('pishfactors')->where('id', $log->id)->update(array(
                'area_id' => $Customer ? $Customer->area : 0,
                'region_id' => $Area ? $Area->region_id : 0,
                'city_id' => $Region ? $Region->city_id : 0,
            ));
        }
    }

    //dd($Logs);
    //$Customers = DB::table('customers')->where('role_id', $role->id)->pluck('store_id');

});
Route::get('/update_factor_fullprices', function () {

    $userID = auth()->user()->id;
    $Logs = DB::table('pishfactors')->get();


    foreach ($Logs as $log) {
        $Items = DB::table('pish_factor_items')->where('pishfactor_id', $log->id)->get();
        $allpacks = 0;
        $allitems = 0;
        $allitems_full = 0;
        $item_fees = 0;
        $all_item_fees = 0;
        $all_item_tax = 0;
        $all_discounts  = 0;
        $all_pats = 0;
        $factor_price = 0;

        foreach ($Items as $item) {
            $pr = DB::table('products')->where('id', $item->pr_id)->first();
            $allpacks += intval($item->pack);
            $allitems += intval($item->tedad);
            $items = intval($pr->pack_items) * intval($item->pack) + intval($item->tedad);
            $allitems_full += intval($items);
            $item_fees += intval($item->price);
            $fee_price = intval($items) * intval($item->price);
            $all_item_fees += $fee_price;
            $disprice = (intval($items) * intval($item->price)) * intval($item->discount) / 100;
            $pat = intval($fee_price) - intval($disprice);
            $all_discounts += $disprice;
            $all_pats += $pat;
            $taxprice = intval(($pat * $pr->tax) / 100);
            $all_item_tax += $taxprice;
            $fullp = intval($pat) + intval($taxprice);
            $factor_price += $fullp;
        }



        echo "<p style='direction: rtl'> فاکتور شماره: " . $log->id . " /// پس از تخفیف: " . $all_pats . " /// قیمت کل: " . $factor_price . " </p><hr />";

        DB::table('pishfactors')->where('id', $log->id)->update(array(
            'fullPrice' => str_replace(",", "", $factor_price),
            'pat_price' => str_replace(",", "", $all_pats),
        ));
    }

    //dd($Logs);
    //$Customers = DB::table('customers')->where('role_id', $role->id)->pluck('store_id');

});
Route::get('/update_customer_organ', function () {

    $userID = auth()->user()->id;
    $Logs = DB::table('customers')->get();
    foreach ($Logs as $log) {
        if ($log->organization_id == null) {
            $Area = DB::table('areas')->where('id', $log->area)->first();
            $Region = DB::table('regions')->where('id', $Area->region_id)->first();
            DB::table('customers')->where('id', $log->id)->update(array(
                'organization_id' => $Region->organization_id,
            ));
        }
    }

    //dd($Logs);
    //$Customers = DB::table('customers')->where('role_id', $role->id)->pluck('store_id');

});

Route::get('/check_customer_creator', function () {

    $userID = auth()->user()->id;
    $Logs = DB::table('logs')->get();
    foreach ($Logs as $log) {
        if (str_starts_with($log->description, 'یک مشتری')) {
            $LogArray = explode('-', $log->description);
            $CustomerName = $LogArray[1];
            DB::table('customers')->where('name', $CustomerName)->update(array(
                'created_by' => $log->user_id,
            ));
        }
    }

    //dd($Logs);
    //$Customers = DB::table('customers')->where('role_id', $role->id)->pluck('store_id');

});
