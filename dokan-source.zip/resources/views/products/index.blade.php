<!DOCTYPE html>
<html class="light-style layout-navbar-fixed layout-menu-fixed layout-compact" data-assets-path="{{ asset('assets/') }}/"
    data-template="vertical-menu-template-no-customizer" data-theme="theme-default" dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8" />
    <meta content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
        name="viewport" />
    <title>لیست محصولات - دکان دارمینو</title>
    <meta content="" name="description" />
    <!-- Favicon -->
    <link href="{{ asset('assets/') }}/img/favicon/favicon.ico" rel="icon" type="image/x-icon" />
    <!-- Icons -->
    <link href="{{ asset('assets/') }}/vendor/fonts/fontawesome.css" rel="stylesheet" />
    <link href="{{ asset('assets/') }}/vendor/fonts/tabler-icons.css" rel="stylesheet" />
    <link href="{{ asset('assets/') }}/vendor/fonts/flag-icons.css" rel="stylesheet" />
    <!-- Core CSS -->
    <link href="{{ asset('assets/') }}/vendor/css/rtl/core.css" rel="stylesheet" />
    <link href="{{ asset('assets/') }}/vendor/css/rtl/theme-default.css" rel="stylesheet" />
    <link href="{{ asset('assets/') }}/css/demo.css" rel="stylesheet" />
    <!-- Vendors CSS -->
    <link href="{{ asset('assets/') }}/vendor/libs/node-waves/node-waves.css" rel="stylesheet" />
    <link href="{{ asset('assets/') }}/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" />
    <link href="{{ asset('assets/') }}/vendor/libs/typeahead-js/typeahead.css" rel="stylesheet" />
    <link href="{{ asset('assets/') }}/vendor/libs/datatables-bs5/datatables.bootstrap5.css" rel="stylesheet" />
    <link href="{{ asset('assets/') }}/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css"
        rel="stylesheet" />
    <link href="{{ asset('assets/') }}/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css"
        rel="stylesheet" />

    <!-- Page CSS -->
    <link href="{{ asset('assets/') }}/vendor/libs/select2/select2.css" rel="stylesheet" />
    <!-- Helpers -->
    <script src="{{ asset('assets/') }}/vendor/js/helpers.js"></script>

    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="{{ asset('assets/') }}/js/config.js"></script>
    <!-- Better experience of RTL -->
    <link href="{{ asset('assets/') }}/css/rtl.css" rel="stylesheet" />
    <style>
        div#DataTables_Table_0_length {
            text-align: left;
            padding-left: 15px;
        }
    </style>
</head>

<body>
    @include('sweetalert::alert')
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            @include('sections.sidebar')
            <!-- Layout container -->
            <div class="layout-page">
                @include('sections.header')
                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="py-3 mb-2">
                            <span class="text-muted fw-light">محصولات /</span>
                            لیست محصولات
                        </h4>
                        <!-- Sticky Actions -->

                        <div class="row my-3">
                            <div class="card px-0  mb-5">
                                <div class="card-datatable table-responsive tablelist py-0">
                                    <table class="datatables-direct-basic table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>کد کالا</th>
                                                <th>نام کالا</th>
                                                <th>انبار</th>
                                                <th>واحد پخش</th>
                                                <th>موجودی کالا</th>
                                                <th>واحد اصلی</th>
                                                <th>واحد فرعی</th>
                                                <th>قیمت</th>
                                                <th>عملیات</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php($x = 1)
                                            @foreach ($products as $product)
                                                <tr>
                                                    <th>{{ $x }}</th>
                                                    <td><a
                                                            href="{{ route('products.edit', $product->id) }}">{{ $product->sku }}</a>
                                                    </td>
                                                    <td><a href="{{ route('products.edit', $product->id) }}">{{ $product->title }}
                                                            {{ $product->display_name }}</a></td>
                                                    <td>
                                                        @if (is_array(json_decode($product->store_id)))
                                                            @foreach (json_decode($product->store_id) as $storeid)
                                                                <?php $Store = DB::table('stores')->where('id', $storeid)->first();
                                                                echo $Store->title;
                                                                ?>
                                                            @endforeach
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if (is_array(json_decode($product->organization_id)))
                                                            @foreach (json_decode($product->organization_id) as $organ)
                                                                <?php $Porgan = DB::table('organizations')->where('id', $organ)->first();
                                                                echo $Porgan->title;
                                                                ?>
                                                            @endforeach
                                                        @endif
                                                    </td>
                                                    <td>{{ $product->currentStock() }}</td>
                                                    <td>{{ $product->pr_unit }}</td>
                                                    <td>{{ $product->pr_sub_unit }}</td>
                                                    <td>{{ $product->price > 0 ? number_format(intval($product->price)) : intval($product->price) }}
                                                    </td>
                                                    <td>
                                                        <a href="{{ route('products.edit', $product->id) }}"
                                                            style="font-size:20px;float: right;margin-left:5px"><i
                                                                class="fa fa-edit" style="color:#04a9f5;"></i></a>
                                                        {{-- <form action="{{ route('stores.destroy', $region->id) }}"
                                                    method="POST"
                                                    onsubmit="return confirm('آیا از حذف رکورد مورد نظر اطمینان دارید؟');">
                                                    @method('delete')
                                                    @csrf
                                                    <button type="submit"
                                                        style="font-size:20px;border: none;background-color: transparent;float: right;">
                                                        <i class="fa fa-trash" style="color:#dc3545;"></i>
                                                    </button>
                                                </form> --}}
                                                    </td>
                                                </tr>
                                                @php($x++)
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            @foreach ($products as $product)
                                <div class="col-md-6 col-lg-3 mb-3 pr_item">
                                    <div class="card">
                                        <img alt="درپوش تصویر کارت" class="card-img-top"
                                            src="{{ $product->photo == null ? asset('/img/core-img/placeholder-image.png') : asset("/storage/uploads/$product->photo") }}"
                                            style="width: 330px;height: 330px" />
                                        <div class="card-body p-2">
                                            <h5 class="card-title mb-2">{{ $product->title }}
                                                {{ $product->display_name }}</h5>
                                        </div>
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item text-end pricepr">
                                                {{ $product->price > 0 ? number_format(intval($product->price)) : 0 }}
                                                ریال</li>
                                        </ul>
                                        <div class="d-flex counterbox">
                                            @if (isset($_GET['Customer']))
                                                <span class="col-2 minus">-</span>
                                                <input type="number" class="inputcount col-8" />
                                                <span class="col-2 plus">+</span>
                                            @endif
                                        </div>
                                        <div class="card-body col-12 w-100">
                                            <a class="btn btn-icon btn-outline-secondary ml-2"
                                                href="{{ route('products.edit', $product->id) }}" title="ویرایش محصول">
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M11.3502 2.17046L12.6098 0.910099C12.8723 0.647517 13.2285 0.5 13.5998 0.5C13.9712 0.5 14.3273 0.647517 14.5899 0.910099C14.8525 1.17268 15 1.52882 15 1.90017C15 2.27151 14.8525 2.62765 14.5899 2.89023L6.66115 10.819C6.26641 11.2135 5.77962 11.5035 5.24474 11.6627L3.23997 12.26L3.8373 10.2553C3.99654 9.72038 4.28651 9.23359 4.68102 8.83885L11.3502 2.17046ZM11.3502 2.17046L13.3198 4.14014M12.1999 9.2734V12.82C12.1999 13.2656 12.0229 13.6929 11.7078 14.0079C11.3927 14.323 10.9654 14.5 10.5199 14.5H2.67998C2.23442 14.5 1.80711 14.323 1.49205 14.0079C1.177 13.6929 1 13.2656 1 12.82V4.98013C1 4.53457 1.177 4.10726 1.49205 3.7922C1.80711 3.47714 2.23442 3.30015 2.67998 3.30015H6.2266"
                                                        stroke="#979797" stroke-width="0.5" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg>
                                            </a>
                                            <a class="btn btn-icon btn-outline-secondary ml-2" href="#">
                                                <svg width="16" height="17" viewBox="0 0 16 17" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M10.3248 6.03874L10.0313 13.4232M5.96873 13.4232L5.67515 6.03874M14.1328 3.40497C14.423 3.44763 14.7115 3.49276 15 3.54117M14.1328 3.40497L13.2267 14.7958C13.1897 15.2596 12.973 15.6928 12.62 16.0087C12.267 16.3247 11.8037 16.5001 11.3227 16.5H4.67733C4.19632 16.5001 3.73299 16.3247 3.37998 16.0087C3.02698 15.6928 2.81032 15.2596 2.77333 14.7958L1.86715 3.40497M14.1328 3.40497C13.1536 3.2618 12.1693 3.15315 11.1818 3.07923M1.86715 3.40497C1.57697 3.44681 1.28848 3.49194 1 3.54035M1.86715 3.40497C2.84642 3.26181 3.83074 3.15316 4.81818 3.07923M11.1818 3.07923V2.32766C11.1818 1.35948 10.4097 0.552119 9.40848 0.52176C8.46973 0.492747 7.53027 0.492747 6.59152 0.52176C5.5903 0.552119 4.81818 1.3603 4.81818 2.32766V3.07923M11.1818 3.07923C9.06376 2.92094 6.93624 2.92094 4.81818 3.07923"
                                                        stroke="#979797" stroke-width="0.5" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg>

                                            </a>
                                            <a href="{{ route('products.edit', $product->id) }}"
                                                class="btn btn-outline-secondary float-end" type="button">
                                                جزئیات محصول
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        <!-- /Sticky Actions -->
                    </div>
                    <!-- / Content -->
                    @include('sections.footer')
                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>
        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
        <!-- Drag Target Area To SlideIn Menu On Small Screens -->
        <div class="drag-target"></div>
    </div>
    <!-- / Layout wrapper -->
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="{{ asset('assets/') }}/vendor/libs/jquery/jquery.js"></script>
    <script src="{{ asset('assets/') }}/vendor/libs/popper/popper.js"></script>
    <script src="{{ asset('assets/') }}/vendor/js/bootstrap.js"></script>
    <script src="{{ asset('assets/') }}/vendor/libs/node-waves/node-waves.js"></script>
    <script src="{{ asset('assets/') }}/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="{{ asset('assets/') }}/vendor/libs/hammer/hammer.js"></script>
    <script src="{{ asset('assets/') }}/vendor/libs/typeahead-js/typeahead.js"></script>
    <script src="{{ asset('assets/') }}/vendor/js/menu.js"></script>
    <!-- endbuild -->
    <script src="{{ asset('assets/') }}/vendor/libs/jquery-sticky/jquery-sticky.js"></script>
    <script src="{{ asset('assets/') }}/vendor/libs/cleavejs/cleave.js"></script>
    <script src="{{ asset('assets/') }}/vendor/libs/cleavejs/cleave-phone.js"></script>
    <script src="{{ asset('assets/') }}/vendor/libs/select2/select2.js"></script>
    <script src="{{ asset('assets/') }}/vendor/libs/datatables-bs5/datatables-bootstrap5.js"></script>
    <!-- Main JS -->
    <script src="{{ asset('assets/') }}/js/main.js"></script>
    <!-- Page JS -->
    <script src="{{ asset('assets/') }}/js/form-layouts.js"></script>
    <script>
        $('.products').addClass('open')
        $('.products .productslist').addClass('active open')
        // datatable (jquery)

        $(document).ready(function() {
            var currentStatusFilter = @json($statusFilter ?? 'active');
            var table = $('.datatables-direct-basic').DataTable({
                searching: true,
                lengthChange: true,
                ordering: true,
                pageLength: 50,
                language: {
                    search: 'جستجو: ',
                    searchPlaceholder: 'جستجو کنید...',
                    info: 'نمایش صفحه _PAGE_ از _PAGES_',
                    infoEmpty: 'موردی وجود ندارد.',
                    infoFiltered: '(فیلتر شده _MAX_ از records)',
                    lengthMenu: 'نمایش _MENU_ مورد در صفحه',
                    zeroRecords: 'متاسفانه موردی پیدا نشد',
                    paginate: {
                        previous: 'قبلی',
                        next: 'بعدی'
                    }
                },
                autoWidth: false, // خاموش کردن تعیین عرض خودکار
                columnDefs: [{
                        width: "30px",
                        targets: 0
                    }, // ستون شماره
                    {
                        width: "60px",
                        targets: 1
                    }, // ستون نام کالا
                    {
                        width: "250px",
                        targets: 2
                    }, // ستون نام کالا
                    {
                        width: "160px",
                        targets: 3
                    }, // ستون انبار
                    {
                        width: "160px",
                        targets: 4
                    }, // ستون انبار
                    {
                        width: "90px",
                        targets: 5
                    }, // موجودی کالا
                    {
                        width: "60px",
                        targets: 6
                    }, // واحد اصلی
                    {
                        width: "60px",
                        targets: 7
                    }, // واحد فرعی
                    {
                        width: "120px",
                        targets: 8
                    }, // قیمت
                    {
                        width: "50px",
                        targets: 9
                    } // عملیات
                ],
                initComplete: function() {
                    var api = this.api();

                    var $select = $(
                        '<select class="form-select" style="width:auto; display:inline-block; margin-right:40px;">' +
                        '<option value="">همه انبارها</option>' +
                        '</select>');
                    var $statusSelect = $(
                        '<select class="form-select" style="width:auto; display:inline-block; margin-right:12px;">' +
                        '<option value="active">فقط فعال</option>' +
                        '<option value="inactive">فقط غیرفعال</option>' +
                        '<option value="all">همه وضعیت ها</option>' +
                        '</select>'
                    );

                    $statusSelect.val(currentStatusFilter);

                    api.column(3).data().unique().sort().each(function(d) {
                        d = d.trim();
                        if (d.length) $select.append('<option value="' + d + '">' + d +
                            '</option>');
                    });

                    // قرار دادن کنار جستجو
                    $('.dataTables_filter label').append($select).append($statusSelect);

                    // اعمال فیلتر روی ستون
                    $select.on('change', function() {
                        var val = $.fn.dataTable.util.escapeRegex($(this).val());
                        api.column(3).search(val ? '^' + val + '$' : '', true, false).draw();
                    });

                    $statusSelect.on('change', function() {
                        var params = new URLSearchParams(window.location.search);
                        params.set('status_filter', $(this).val());
                        window.location.search = params.toString();
                    });
                }
            });
        });





        $('.counterbox .plus').click(function() {
            itemcount = $(this).siblings('.inputcount').val();
            if (parseInt(itemcount) > 0) {
                $(this).siblings('.inputcount').val(eval(parseInt(itemcount) + 1))
            } else {
                $(this).siblings('.inputcount').val(1)
            }
        });

        $('.counterbox .minus').click(function() {
            itemcount = $(this).siblings('.inputcount').val();
            if (parseInt(itemcount) > 0) {
                $(this).siblings('.inputcount').val(eval(parseInt(itemcount) - 1))
            }
        });
    </script>
</body>

</html>
