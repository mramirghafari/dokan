<!DOCTYPE html>
<html class="light-style layout-navbar-fixed layout-menu-fixed layout-compact" data-assets-path="{{ asset('assets/') }}/" data-template="vertical-menu-template-no-customizer" data-theme="theme-default" dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8"/>
    <meta content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" name="viewport"/>
    <title>تولید به روش استحصال - دکان دارمینو</title>
    <meta content="" name="description"/>
    <!-- Favicon -->
    <link href="{{ asset('assets/') }}/img/favicon/favicon.ico" rel="icon" type="image/x-icon"/>
    <!-- Icons -->
    <link href="{{ asset('assets/') }}/vendor/fonts/fontawesome.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/fonts/tabler-icons.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/fonts/flag-icons.css" rel="stylesheet"/>
    <!-- Core CSS -->
    <link href="{{ asset('assets/') }}/vendor/css/rtl/core.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/css/rtl/theme-default.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/css/demo.css" rel="stylesheet"/>
    <!-- Vendors CSS -->
    <link href="{{ asset('assets/') }}/vendor/libs/node-waves/node-waves.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/typeahead-js/typeahead.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/datatables-bs5/datatables.bootstrap5.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css" rel="stylesheet"/>

    <!-- Page CSS -->
    <link href="{{ asset('assets/') }}/vendor/libs/select2/select2.css" rel="stylesheet"/>
    <!-- Helpers -->
    <script src="{{ asset('assets/') }}/vendor/js/helpers.js"></script>

    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="{{ asset('assets/') }}/js/config.js"></script>
    <!-- Better experience of RTL -->
    <link href="{{ asset('assets/') }}/css/rtl.css" rel="stylesheet"/>
</head>

<body>
<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('sections.sidebar')
        <!-- Layout container -->
        <div class="layout-page">
           @include('sections.header')
            <!-- Content wrapper -->
            <div class="content-wrapper">
                <!-- Content -->
                <div class="container-xxl flex-grow-1 container-p-y">
                    <h4 class="py-3 mb-4">
                        <span class="text-muted fw-light">تولید و انبار /</span>
                        تولید به روش استحصال
                    </h4>
                    <!-- Sticky Actions -->
                    <div class="row mt-5">
                        <div class="col-12 order-1 order-lg-2 mb-4 mb-lg-0">


                            <form method="POST" action="{{ route('stocks.ProductionByExtractionProcess') }}">
                                @csrf
                                <div class="card">
                                    <div class="row my-3 px-3">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-6">
                                                    <label for="exampleInputEmail12">انتخاب ماده اولیه:</label>
                                                    <select class="js-example-basic-single form-select" id="material_id" name="material_id"
                                                            style="width: 100%;">
                                                        <option value="">--انتخاب کنید--</option>
                                                        @foreach($Materials as $material)
                                                            <option value="{{ $material->id }}" data-unit="{{ $material->pr_unit }}" data-subunit="{{ $material->pr_sub_unit }}" data-stock="{{ $material->current_stock > 0 ? $material->current_stock : '0' }}">{{ $material->title }} {{ $material->display_name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="col-6 entity_box d-none">
                                                    <div class="col-6">
                                                        <label for="exampleInputEmail12">مقدار وارده: <span class="unitplace"></span></label>
                                                        <input type="number" id="entity" class="form-control" name="entity" placeholder="مقدار وارده" />
                                                        <small class="stock_error text-danger"></small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 d-flex justify-content-end align-items-center">
                                            <button type="button" class="btn btn-primary btn-sm addpr">+ افزودن محصول</button>

                                        </div>
                                    </div>
                                    <div class="card-datatable table-responsive py-0 prbox d-none">
                                        <table class="table yellow">
                                            <thead>
                                            <tr>
                                                <th width="40">ردیف</th>
                                                <th>نام کالا</th>
                                                <th>درصد</th>
                                                <th>مقدار استحصال</th>
                                                <th>مقدار طعم دار</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @php($x = 1)
                                            @foreach($Products as $product)
                                            <tr>
                                                <td>{{ $x }}</td>
                                                <td>
                                                    <input type="text" class="form-control" value="{{ $product->title }} {{ $product->display_name }}" readonly>
                                                    <input type="hidden" name="prs[]" value="{{ $product->id }}">
                                                </td>
                                                <td class="darsad" style="direction: ltr;text-align:right"></td>
                                                <td><input type="text" class="form-control estehsal" name="estehsal[]" /></td>
                                                <td><input type="text" class="form-control taamdar" name="taamdar[]" /></td>
                                            </tr>
                                                @php($x++)
                                            @endforeach
                                            </tbody>
                                            <tfoot class="d-none">
                                            <tr>
                                                <th colspan="2">مقدار</th>
                                                <th class="fullpercent"></th>
                                                <th class="fullestehsal"></th>
                                                <th class="fulltaamdar"></th>
                                            </tr>
                                            <tr>
                                                <th colspan="3" class="text-start text-right" style="text-align: right !important;">مجموع تولید: <span class="jamtolid"></span> <span class="unitplace"></span></th>
                                                <th colspan="2" class="text-end text-left">مجموع کسری اضافه: <span class="jamKasri"></span> <span class="unitplace"></span></th>
                                            </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                                <div class="row justify-content-end mt-3">
                                    <div class="col-12 col-md-3 text-end">
                                        <button type="submit" class="btn btn-primary">ثبت رسید انبار</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /Sticky Actions -->
                </div>
                <!-- / Content -->
                @include('sections.footer')
                <div class="content-backdrop fade"></div>
            </div>
            <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
    </div>
    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
    <!-- Drag Target Area To SlideIn Menu On Small Screens -->
    <div class="drag-target"></div>
</div>
<!-- / Layout wrapper -->
<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="{{ asset('assets/') }}/vendor/libs/jquery/jquery.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/popper/popper.js"></script>
<script src="{{ asset('assets/') }}/vendor/js/bootstrap.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/node-waves/node-waves.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/hammer/hammer.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/typeahead-js/typeahead.js"></script>
<script src="{{ asset('assets/') }}/vendor/js/menu.js"></script>
<!-- endbuild -->
<script src="{{ asset('assets/') }}/vendor/libs/jquery-sticky/jquery-sticky.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/cleavejs/cleave.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/cleavejs/cleave-phone.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/select2/select2.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/datatables-bs5/datatables-bootstrap5.js"></script>
<!-- Main JS -->
<script src="{{ asset('assets/') }}/js/main.js"></script>
<!-- Page JS -->
<script src="{{ asset('assets/') }}/js/form-layouts.js"></script>
<script src="
https://cdn.jsdelivr.net/npm/sweetalert2@11.22.2/dist/sweetalert2.all.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/sweetalert2@11.22.2/dist/sweetalert2.min.css
" rel="stylesheet">
<script>
    // datatable (jquery)
    $(function () {
        var
            dt_without_ajax_table = $('.datatables-direct-basic');

        // DataTable Direct
        // --------------------------------------------------------------------
        if(dt_without_ajax_table.length){
            dt_without_ajax = dt_without_ajax_table.DataTable({
                searching: false,
                lengthChange: false,
                ordering: false,
                pageLength: 5,
            });

            $('.datatables-direct-basic tbody').on( 'click', '.dropdown-item.delete-record', function () {
                dt_without_ajax
                    .row( $(this).parents('tr') )
                    .remove()
                    .draw();
            } );
        }


    });

    $(document).ready(function() {
        $('#material_id').on('change',function() {
            var dataUnit = $(this).find('option:selected').attr('data-unit');
            $('.unitplace').html("("+dataUnit+")");
            var dataSubUnit = $(this).find('option:selected').attr('data-subunit');
            var dataStock = $(this).find('option:selected').attr('data-stock');
            $('.subunitplace').html(dataSubUnit);
            $('#entity').val(dataStock);
            $('.entity_box').removeClass('d-none');

        });


        $('#entity').on('keyup',function() {
            var typin = $(this).val();
            var stock = $('#material_id').find('option:selected').attr('data-stock');
            if(stock == 0) {
                $(this).val(0)
            }else {
                if(parseInt(typin) > parseInt(stock)) {
                    $('.stock_error').html('مقدار وارد شده از موجودی محصول بیشتر است.');
                }else {
                    $('.stock_error').html('');
                }
            }
        });

        $('.addpr').click(function() {
            var entity = $('#entity').val();
            if(entity > 0) {
                $('.prbox').removeClass('d-none')

               /*  var counter = $('.table tbody tr').length+1
                $('.table tbody').append('<tr><td>'+counter+'</td><td><select class="form-control" name="prs[]"><option>انتخاب محصول</option>@foreach($Products as $product)<option value="{{ $product->id }}">{{ $product->title }} {{ $product->display_name }}</option>@endforeach' +
                    '</select></td><td class="darsad" style="direction: ltr;text-align:right"></td><td><input type="text" class="form-control estehsal" name="estehsal[]" /></td><td><input type="text" class="form-control taamdar" name="taamdar[]" /></td></tr>');
                $('tfoot').removeClass('d-none'); */
            }else {
                Swal.fire({
                    icon: "error",
                    title: "خطا",
                    text: "مقدار ماده اولیه مشخص نشده",
                    confirmButtonText: 'باشه',
                });
            }

        });

        // تابع برای به روز رسانی مقادیر کلی (فقط estehsal کل)
        function updateOverallTotals() {
            var totalEstehsal = 0;
            var totalAllowedWeight = parseFloat($('#entity').val());

            $('.table tbody tr').each(function() {
                var currentEstehsal = parseFloat($(this).find('.estehsal').val() || 0);
                totalEstehsal += currentEstehsal;
            });

            // نمایش جمع کل استحصالح در المان .fullestehsal
            $('.fullestehsal').html(totalEstehsal.toFixed(2));

            // چون taamdar محاسبه نمی‌شود (فقط محدودیت ردیفی دارد), مقدارش را 0.00 قرار می‌دهیم
            $('.fulltaamdar').html('0.00');
            var finalOverallPercent = 0;
            if (totalAllowedWeight > 0) {
                // درصد کلی بر اساس مجموع estehsal و وزن کل مجاز
                finalOverallPercent = (totalEstehsal / totalAllowedWeight) * 100;
            }
            $('.fullpercent').html('%' + finalOverallPercent.toFixed(2));
        }


// Event listener اصلی برای estehsal
        $('.table').on('input', '.estehsal', function () {
            var totalAllowedWeight = parseFloat($('#entity').val());
            var currentRow = $(this).closest('tr');

            var currentEstehsal = parseFloat($(this).val());
            if (isNaN(currentEstehsal)) currentEstehsal = 0;

            var sumOfPreviousRowsEstehsal = 0;
            currentRow.prevAll().each(function() {
                var prevEstehsal = parseFloat($(this).find('.estehsal').val() || 0);
                sumOfPreviousRowsEstehsal += prevEstehsal;
            });

            var remainingOverallAllowedWeight = totalAllowedWeight - sumOfPreviousRowsEstehsal;

            if (currentEstehsal > remainingOverallAllowedWeight) {
                var newEstehsal = remainingOverallAllowedWeight;
                if (newEstehsal < 0) newEstehsal = 0;
                $(this).val(newEstehsal.toFixed(2));
                currentEstehsal = newEstehsal;
            }

            // حالا که estehsal تغییر کرده، محدودیت taamdar را هم بررسی می‌کنیم
            var currentTaamdarField = currentRow.find('.taamdar');
            var currentTaamdar = parseFloat(currentTaamdarField.val() || 0);

            // اینجا از Math.floor() استفاده می‌کنیم تا اعشار را حذف کنیم
            if (currentTaamdar > currentEstehsal) {
                currentTaamdarField.val(Math.floor(currentEstehsal)); // تغییر به Math.floor
            }


            var percent = (currentEstehsal / totalAllowedWeight) * 100;
            var percentText = (percent % 1 === 0) ? percent.toFixed(0) : percent.toFixed(2);
            currentRow.find('.darsad').html('%' + percentText);

            updateOverallTotals();
        });

// Event listener جدید برای taamdar
        $('.table').on('input', '.taamdar', function () {
            var currentRow = $(this).closest('tr');
            var currentTaamdar = parseFloat($(this).val());
            if (isNaN(currentTaamdar)) currentTaamdar = 0;

            var currentEstehsal = parseFloat(currentRow.find('.estehsal').val() || 0);

            // اعمال محدودیت: taamdar نباید از estehsal بیشتر باشد
            // اینجا از Math.floor() استفاده می‌کنیم تا اعشار را حذف کنیم
            if (currentTaamdar > currentEstehsal) {
                $(this).val(Math.floor(currentEstehsal)); // تغییر به Math.floor
            }
        });


// هنگام بارگذاری اولیه صفحه (اگر مقادیری از قبل وجود دارد)
        $(document).ready(function() {
            updateOverallTotals();
        });




    });

</script>
</body>

</html>
