<!DOCTYPE html>
<html class="light-style layout-navbar-fixed layout-menu-fixed layout-compact" data-assets-path="{{ asset('assets/') }}/" data-template="vertical-menu-template-no-customizer" data-theme="theme-default" dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8"/>
    <meta content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" name="viewport"/>
    <title>ویرایش پنل - دکان دارمینو</title>
    <meta content="" name="description"/>
    <!-- Favicon -->
    <link href="{{ asset('assets/') }}/img/favicon/favicon.ico" rel="icon" type="image/x-icon"/>
    <!-- Icons -->
    <link href="{{ asset('assets/') }}/vendor/fonts/fontawesome.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/fonts/tabler-icons.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/fonts/flag-icons.css" rel="stylesheet"/>
    <!-- Core CSS -->
    <link href="{{ asset('assets/') }}/vendor/css/rtl/core.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/css/rtl/theme-default.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/css/demo.css" rel="stylesheet"/>
    <!-- Vendors CSS -->
    <link href="{{ asset('assets/') }}/vendor/libs/node-waves/node-waves.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/typeahead-js/typeahead.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/datatables-bs5/datatables.bootstrap5.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css" rel="stylesheet"/>
    <link href="{{ asset('assets/') }}/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css" rel="stylesheet"/>

    <!-- Page CSS -->
    <link href="{{ asset('assets/') }}/vendor/libs/select2/select2.css" rel="stylesheet"/>
    <!-- Helpers -->
    <script src="{{ asset('assets/') }}/vendor/js/helpers.js"></script>

    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="{{ asset('assets/') }}/js/config.js"></script>
    <!-- Better experience of RTL -->
    <link href="{{ asset('assets/') }}/css/rtl.css" rel="stylesheet"/>
</head>

<body>
@include('sweetalert::alert')
<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">

    <div class="layout-container">
        @include('sections.sidebar')
        <!-- Layout container -->
        <div class="layout-page">
           @include('sections.header')
            <!-- Content wrapper -->
            <div class="content-wrapper">
                <!-- Content -->
                <div class="container-xxl flex-grow-1 container-p-y">
                    <h4 class="py-3 mb-4">
                        <span class="text-muted fw-light">اطلاعات پایه /</span>
                        ویرایش مشخصات پنل
                    </h4>
                    <!-- Sticky Actions -->
                    <div class="row mt-5">
                        <div class="col-12 order-1 order-lg-2 mb-4 mb-lg-0">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <form action="{{ route('tenants.update',$Tenant->id) }}" method="POST">
                                        @csrf
                                        @method('PATCH')
                                        <div class="mb-3">
                                            <label class="form-label" for="name">نام پنل</label>
                                            <input class="form-control" name="name" id="name" placeholder="نام پنل" value="{{ $Tenant->name }}" type="text"/>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label" for="unit_order">واحد اصلی سفارش گیری محصولات</label>
                                            <select class="select2 form-select" data-allow-clear="true" id="unit_order" name="unit_order">
                                                <option value="">انتخاب کنید</option>
                                                <option value="مثقال" @if($Tenant->unit_order == 'مثقال') selected @endif>مثقال</option>
                                                <option value="گرم" @if($Tenant->unit_order == 'گرم') selected @endif>گرم</option>
                                                <option value="کیلوگرم" @if($Tenant->unit_order == 'کیلوگرم') selected @endif>کیلوگرم</option>
                                                <option value="تن" @if($Tenant->unit_order == 'تن') selected @endif>تن</option>
                                                <option value="سی سی" @if($Tenant->unit_order == 'سی سی') selected @endif>سی سی </option>
                                                <option value="میلی لیتر" @if($Tenant->unit_order == 'میلی لیتر') selected @endif>میلی لیتر</option>
                                                <option value="لیتر" @if($Tenant->unit_order == 'ملیترثقال') selected @endif>لیتر</option>
                                                <option value="عدد" @if($Tenant->unit_order == 'عدد') selected @endif>عدد</option>
                                            </select>
                                            <small>این واحد در تیتر جدول ها نمایش داده میشود.</small>
                                        </div>
                                        <div class="mb-3">
                                            <label for="sub_unit">انتخاب واحد فرعی سفارش گیری:</label>
                                            <select class="form-control" id="sub_unit" name="sub_unit">
                                                <option>-- انتخاب کنید --</option>
                                                <option value="نایلون" @if($Tenant->sub_unit == 'نایلون') selected @endif>نایلون</option>
                                                <option value="کارتن" @if($Tenant->sub_unit == 'کارتن') selected @endif>کارتن</option>
                                                <option value="فله" @if($Tenant->sub_unit == 'فله') selected @endif>فله</option>
                                            </select>
                                        </div>
                                        <div class="row g-2">
                                            <div class="col mb-3">
                                                <label for="currency_type">واحد پولی پنل:</label>
                                                <select class="form-control" id="currency_type" name="currency_type">
                                                    <option value="0">-- انتخاب کنید --</option>
                                                    <option value="1" @if($Tenant->currency_type == 1) selected @endif>تومان</option>
                                                    <option value="2" @if($Tenant->currency_type == 2) selected @endif>ریال</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row g-2">
                                            <div class="col mb-3">
                                                <label for="status">وضعیت پنل:</label>
                                                <select class="form-control" id="status" name="status">
                                                    <option value="1" @if($Tenant->status == 1) selected @endif>فعال</option>
                                                    <option value="2" @if($Tenant->status == 0) selected @endif>غیرفعال</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="tozihat">توضیح:</label>
                                            <input type="text" class="form-control" name="tozihat" id="tozihat" value="{{ $Tenant->tozihat }}">
                                        </div>
                                        <button class="btn btn-primary" type="submit">ویرایش شعبه</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /Sticky Actions -->
                </div>
                <!-- / Content -->
                @include('sections.footer')
                <div class="content-backdrop fade"></div>
            </div>
            <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
    </div>
    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
    <!-- Drag Target Area To SlideIn Menu On Small Screens -->
    <div class="drag-target"></div>
</div>
<!-- / Layout wrapper -->
<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="{{ asset('assets/') }}/vendor/libs/jquery/jquery.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/popper/popper.js"></script>
<script src="{{ asset('assets/') }}/vendor/js/bootstrap.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/node-waves/node-waves.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/hammer/hammer.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/typeahead-js/typeahead.js"></script>
<script src="{{ asset('assets/') }}/vendor/js/menu.js"></script>
<!-- endbuild -->
<script src="{{ asset('assets/') }}/vendor/libs/jquery-sticky/jquery-sticky.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/cleavejs/cleave.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/cleavejs/cleave-phone.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/select2/select2.js"></script>
<script src="{{ asset('assets/') }}/vendor/libs/datatables-bs5/datatables-bootstrap5.js"></script>
<!-- Main JS -->
<script src="{{ asset('assets/') }}/js/main.js"></script>
<!-- Page JS -->
<script src="{{ asset('assets/') }}/js/form-layouts.js"></script>
<script>
    // datatable (jquery)
    $('.basicdata').addClass('open')
    $('.basicdata .tenants').addClass('active open')
    $(function () {
        var
            dt_without_ajax_table = $('.datatables-direct-basic');

        // DataTable Direct
        // --------------------------------------------------------------------
        if(dt_without_ajax_table.length){
            dt_without_ajax = dt_without_ajax_table.DataTable({
                searching: false,
                lengthChange: false,
                ordering: false,
                pageLength: 5,
            });

            $('.datatables-direct-basic tbody').on( 'click', '.dropdown-item.delete-record', function () {
                dt_without_ajax
                    .row( $(this).parents('tr') )
                    .remove()
                    .draw();
            } );
        }


    });

</script>
</body>

</html>
