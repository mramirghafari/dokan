<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProductRequest;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;
use App\Models\Customers;
use App\Models\Tasks;
use App\Models\Brand;
use App\Models\History;
use App\Models\Log;
use App\Models\Organization;
use App\Models\Store;
use App\Models\Depot;
use App\Models\Region;
use App\Models\Area;
use App\Models\PriceLog;
use Auth;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;
use Hekmatinasser\Verta\Verta;

class ProductController extends Controller
{
    public function __construct()
    {
        $this->middleware('can:products,user')->only(['index', 'destroy', 'trashGet', 'trashPost', 'restore']);
        $this->middleware('can:product-add,user,neworder')->only(['create', 'store', 'edit', 'update']);
    }

    public function index(Request $request)
    {

        $categories = Category::where('isActive', 1)->where('parent_id', '')->get();
        $brands = Brand::where('isActive', 1)->get();

        //Stores
        $user = \Auth::user();

        $isVisitor = false;
        $isLeader = false;
        $isManager = false;
        $isAgent = false;
        $statusFilter = $request->get('status_filter', 'active');

        $productsQuery = Product::forOrganizations($user)->where('isMaterial', 0);
        if ($statusFilter === 'active') {
            $productsQuery->where('isActive', 1);
        } elseif ($statusFilter === 'inactive') {
            $productsQuery->where('isActive', 0);
        }
        $products = $productsQuery->orderBy('id', 'desc')->get();

        $organizations = Organization::forOrganizations($user, 'id')->get();
        foreach ($user->roles as $role) {
            $storesUser = DB::table('role_store')->where('role_id', $role->id)->pluck('store_id');
            if ($role->title == 'visitor') {
                $isVisitor = true;
                $products = Product::forOrganizations($user)->where('isActive', 1)->where('isMaterial', 0)->orderBy('id', 'desc')->get();
            }
            if ($role->title == 'leader') {
                $isLeader = true;
                $products = Product::forOrganizations($user)->where('isActive', 1)->where('isMaterial', 0)->orderBy('id', 'desc')->get();
            }
            if ($this->isAgentLikeRole($role)) {
                $isAgent = true;
                $products = Product::forOrganizations($user)->where('isActive', 1)->where('isMaterial', 0)->orderBy('id', 'desc')->get();
            }
            if ($role->title == 'manager') {
                $isManager = true;
            }
            $stores = Store::whereIn('id', $storesUser)->where('isActive', 1)->get();
        }

        if ($isVisitor) {
            $MyAreas = Tasks::where('user_id', auth()->user()->id)->pluck('area_id')->toArray();
            $Customers = Customers::whereIn('area', $MyAreas)->get();
            if ($request->has('Task')) {
                $Task = $request->Task;
            } else {
                $Task = null;
            }

            return view('products.visitor_index', compact('products', 'stores', 'categories', 'brands', 'organizations', 'Customers', 'Task', 'isAgent'));
        } elseif ($isAgent) {
            $Customers = collect();
            $Task = null;

            return view('products.visitor_index', compact('products', 'stores', 'categories', 'brands', 'organizations', 'Customers', 'Task', 'isAgent'));
        } elseif ($isLeader) {
            $MyAreas = Tasks::where('leader_id', auth()->user()->id)->pluck('area_id')->toArray();
            $Customers = Customers::whereIn('area', $MyAreas)->get();
            if ($request->has('Task')) {
                $Task = $request->Task;
            } else {
                $Task = null;
            }

            return view('products.visitor_index', compact('products', 'stores', 'categories', 'brands', 'organizations', 'Customers', 'Task', 'isAgent'));
        } else {

            if ($request->has('neworder') && $isVisitor == false && $isLeader == false) {
                $products = Product::forOrganizations($user)->where('isActive', 1)->where('isMaterial', 0)->orderBy('id', 'desc')->get();
                $Task = null;
                $Customers = Customers::forOrganizations($user)->orderBy('id', 'desc')->get();
                return view('products.visitor_index', compact('products', 'stores', 'categories', 'brands', 'organizations', 'Customers', 'Task', 'isAgent'));
            }


            return view('products.index', compact('products', 'stores', 'categories', 'brands', 'organizations', 'statusFilter'));
        }
    }

    public function collection()
    {

        $user = \Auth::user();
        if ($user->isAdmin == 1) {
            $organizations = Organization::all();
            $products = Product::forOrganizations($user)->where('isActive', 1)->where('isMaterial', 0)->latest()->get();
            $productCount = Product::onlyTrashed()->count();
            $stores = Store::all();
        } else {
            // $productCount = Product::where('organization_id', $user->organization_id)->onlyTrashed()->count();
            foreach ($user->roles as $role) {
                $storesUser = DB::table('role_store')->where('role_id', $role->id)->pluck('store_id');
            }
            $products = Product::forOrganizations($user)->where('isMaterial', 0)->where('isActive', 1)->latest()->get();
        }
        return view('products.collection', compact('products'));
    }

    public function neworder()
    {

        $categories = Category::where('isActive', 1)->where('parent_id', '')->get();
        $brands = Brand::where('isActive', 1)->get();

        //Stores
        $user = \Auth::user();

        $isVisitor = false;
        $isLeader = false;
        $isAgent = false;
        $storesUser = collect();
        foreach ($user->roles as $role) {
            $storesUser = DB::table('role_store')->where('role_id', $role->id)->pluck('store_id');
            if ($role->title == 'visitor') {
                $isVisitor = true;
            }
            if ($role->title == 'leader') {
                $isLeader = true;
            }
            if ($this->isAgentLikeRole($role)) {
                $isAgent = true;
            }
        }

        if ($user->isAdmin == 1) {
            $organizations = Organization::all();
            $products = Product::forOrganizations($user)->where('isMaterial', 0)->where('isActive', 1)->latest()->get();
            $productCount = Product::forOrganizations($user)->where('isMaterial', 0)->where('isActive', 1)->count();
            $stores = Store::all();
        } else {
            $productCount = Product::forOrganizations($user)->where('isMaterial', 0)->where('isActive', 1)->count();
            $organizations = Organization::where('id', $user->organization_id)->get();
            $products = Product::forOrganizations($user)->where('isMaterial', 0)->where('isActive', 1)->latest()->get();


            $stores = Store::whereIn('id', $storesUser)->where('isActive', 1)->get();
        }

        if ($isVisitor) {
            $MyAreas = Tasks::where('user_id', auth()->user()->id)->pluck('area_id')->toArray();
            $Customers = Customers::whereIn('area', $MyAreas)
                ->orderBy('name')
                ->get();
        } elseif ($isLeader) {
            $MyRegions = Region::where('leader_id', auth()->user()->id)->pluck('id')->toArray();
            $MyAreas = Area::whereIn('region_id', $MyRegions)->pluck('id')->toArray();
            $Customers = Customers::whereIn('area', $MyAreas)
                ->orderBy('name')
                ->get();
        } elseif ($isAgent) {
            $Customers = collect();
        } else {
            $Customers = Customers::forOrganizations($user)
                ->orderBy('name')
                ->get();
        }


        return view('products.visitor_index', compact('products', 'stores', 'categories', 'brands', 'organizations', 'productCount', 'Customers', 'isAgent'));
    }

    private function isAgentLikeRole($role): bool
    {
        return in_array($role->title, ['agent', 'reseller'], true)
            || trim((string) ($role->description ?? '')) === 'نماینده';
    }

    public function create()
    {
        $products = Product::all();
        $categories = Category::where('isActive', 1)->where('parent_id', Null)->get();
        $brands = Brand::where('isActive', 1)->get();

        //Stores
        $user = \Auth::user();
        if ($user->isGod == 1) {
            $organizations = Organization::all();
            $stores = Store::all();
        } elseif ($user->isAdmin == 1) {
            $organizations = Organization::where('isActive', 1)->get();
            $stores = Store::forOrganizations($user)->get();
        } else {
            $organizations = Organization::forOrganizations($user, 'id')->where('isActive', 1)->get();
            foreach ($user->roles as $role) {
                $storesUser = DB::table('role_store')->where('role_id', $role->id)->pluck('store_id');
            }
            $stores = Store::whereIn('id', $storesUser)->where('isActive', 1)->get();
        }



        return view('products.create', compact('products', 'stores', 'categories', 'brands', 'organizations'));
    }

    public function store(Request $request)
    {
        $request['user_id'] = \Auth::user()->id;
        $request['organization_id'] = json_encode($request->organization_id);
        $request['store_id'] = json_encode($request->store_id);
        $request->isActive == "on" ? $request['isActive'] = 1 : $request['isActive'] = 0;
        $request->item_sale_status == "on" ? $request['item_sale_status'] = 1 : $request['item_sale_status'] = 0;
        $request->pack_sale_status == "on" ? $request['pack_sale_status'] = 1 : $request['pack_sale_status'] = 0;
        $request->set_price == "on" ? $request['set_price'] = 1 : $request['set_price'] = 0;
        $request->isMaterial == "on" ? $request['isMaterial'] = 1 : $request['isMaterial'] = 0;
        $request->price = str_replace(',', '', $request->price);
        $product = Product::create($request->all());

        $PriceLog = new PriceLog();
        $PriceLog->pr_id = $product->id;
        $PriceLog->price = str_replace(',', '', $request->price);
        $PriceLog->discount = str_replace(',', '', $request->discount);
        $PriceLog->tax = str_replace(',', '', $request->tax);
        $PriceLog->fee_masraf = str_replace(',', '', $request->fee_masraf);
        $PriceLog->fee_masraf = str_replace(',', '', $request->fee_masraf);
        $PriceLog->price_from_fa = $request->price_date;
        $PriceLog->price_exp_fa = $request->price_date_exp;

        if ($request->price_date != '') {
            $jalali = explode("/", $request->price_date);
            $miladi = Verta::jalaliToGregorian($jalali[0], $jalali[1], $jalali[2]);
            $ym = $miladi[0];
            if (strlen($miladi[1]) == 1) {
                $mm = "0" . $miladi[1];
            } else {
                $mm = $miladi[1];
            };
            if (strlen($miladi[2]) == 1) {
                $dm = "0" . $miladi[2];
            } else {
                $dm = $miladi[2];
            };
            $price_date_en = "$ym-$mm-$dm 00:00:00";
        } else {
            $price_date_en = null;
        }


        $PriceLog->price_from_en = $price_date_en;


        if ($request->price_date_exp != '') {
            $jalali = explode("/", $request->price_date_exp);
            $miladi = Verta::jalaliToGregorian($jalali[0], $jalali[1], $jalali[2]);
            $ym = $miladi[0];
            if (strlen($miladi[1]) == 1) {
                $mm = "0" . $miladi[1];
            } else {
                $mm = $miladi[1];
            };
            if (strlen($miladi[2]) == 1) {
                $dm = "0" . $miladi[2];
            } else {
                $dm = $miladi[2];
            };
            $price_exp_en = "$ym-$mm-$dm 00:00:00";
        } else {
            $price_exp_en = null;
        }


        $PriceLog->price_exp_en = $price_exp_en;
        $PriceLog->user_id = auth()->user()->id;

        $PriceLog->save();



        if ($request->hasFile('photo')) {
            $imageName = time() . '.' . $request->file('photo')->getClientOriginalExtension();
            $request->file('photo')->move('storage/uploads', $imageName);
            $product->update([
                'photo' => $imageName
            ]);
        }


        $user = \Auth::user();

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => 'یک محصول ایجاد شد' . '-' . $product->title
        ]);

        History::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'entity',
            'store' => $product->title,
            'description' => " برای کالای " . $product->title . " موجودی اولیه " . $product->entity . " ثبت شد"
        ]);

        $product = Product::find($product->id);
        if ($request->start_date == 1) {
            $product->start_date =  verta()->format('Y/m/d');
        } elseif ($request->start_date == 2) {
            $product->start_date = verta('-1 day')->format('Y/m/d');
        } elseif ($request->start_date == 3) {
            $product->start_date = $request->select_start_date;
        }

        if ($request->exp_date == 1) {
            $product->exp_date =  verta()->format('Y/m/d');
        } elseif ($request->exp_date == 2) {
            $product->exp_date = verta('+1 day')->format('Y/m/d');
        } elseif ($request->exp_date == 3) {
            $product->exp_date = $request->select_exp_date;
        }



        $product->save();

        Alert::success('تشکر', 'رکورد با موفقیت ایجاد شد');
        return redirect(route('products.edit', $product->id));
    }

    public function edit(Product $product)
    {
        $categories = Category::where('isActive', 1)->where('parent_id', Null)->get();
        $brands = Brand::where('isActive', 1)->get();
        $parents = Category::where('isActive', 1)->where('parent_id', '!=', Null)->get();
        $Depots = Depot::where('pr_id', $product->id)->get();
        $PriceLogs = PriceLog::where('pr_id', $product->id)->orderBy('id', 'desc')->get();
        $PriceLogLast = PriceLog::where('pr_id', $product->id)->orderBy('id', 'desc')->first();
        //Stores
        $user = \Auth::user();
        $my_organ = Organization::where('id', $product->organization_id)->first();
        if ($user->isGod == 1) {
            $organizations = Organization::all();
            $stores = Store::all();
        } elseif ($user->isAdmin == 1) {
            $organizations = Organization::where('isActive', 1)->get();
            $stores = Store::forOrganizations($user)->get();
        } else {
            $organizations = Organization::where('id', $user->organization_id)->where('isActive', 1)->get();
            foreach ($user->roles as $role) {
                $storesUser = DB::table('role_store')->where('role_id', $role->id)->pluck('store_id');
            }
            $stores = Store::whereIn('id', $storesUser)->where('isActive', 1)->get();
        }

        return view('products.edit', compact('product', 'categories', 'brands', 'parents', 'organizations', 'stores', 'PriceLogs', 'PriceLogLast', 'my_organ', 'Depots'));
    }

    public function update(Request $request, Product $product)
    {

        //dd($request->all());

        $MainCat = Category::find($product->parentCategory_id);
        $my_organ = Organization::where('id', $product->organization_id)->first();

        $PriceLog = new PriceLog();
        $PriceLog->pr_id = $product->id;
        $PriceLog->price = str_replace(',', '', $request->price);
        $PriceLog->discount = str_replace(',', '', $request->discount);
        $PriceLog->tax = str_replace(',', '', $request->tax);
        $PriceLog->fee_masraf = str_replace(',', '', $request->fee_masraf);
        $PriceLog->fee_masraf = str_replace(',', '', $request->fee_masraf);
        $PriceLog->price_from_fa = $request->price_date;
        $PriceLog->price_exp_fa = $request->price_date_exp;
        if ($request->price_date != null) {
            $jalali = explode("/", $request->price_date);
            $miladi = Verta::jalaliToGregorian($jalali[0], $jalali[1], $jalali[2]);
            $ym = $miladi[0];
            if (strlen($miladi[1]) == 1) {
                $mm = "0" . $miladi[1];
            } else {
                $mm = $miladi[1];
            };
            if (strlen($miladi[2]) == 1) {
                $dm = "0" . $miladi[2];
            } else {
                $dm = $miladi[2];
            };
            $price_date_en = "$ym-$mm-$dm 00:00:00";
        } else {
            $price_date_en = null;
        }


        $PriceLog->price_from_en = $price_date_en;

        if ($request->price_date_exp != null) {
            $jalali = explode("/", $request->price_date_exp);
            $miladi = Verta::jalaliToGregorian($jalali[0], $jalali[1], $jalali[2]);
            $ym = $miladi[0];
            if (strlen($miladi[1]) == 1) {
                $mm = "0" . $miladi[1];
            } else {
                $mm = $miladi[1];
            };
            if (strlen($miladi[2]) == 1) {
                $dm = "0" . $miladi[2];
            } else {
                $dm = $miladi[2];
            };
            $price_exp_en = "$ym-$mm-$dm 00:00:00";
        } else {
            $price_exp_en = null;
        }

        $PriceLog->price_exp_en = $price_exp_en;
        $PriceLog->user_id = auth()->user()->id;

        $PriceLog->save();


        $entity = $product->entity;
        $request->item_sale_status == "on" ? $request->item_sale_status = 1 : $request->item_sale_status = 0;
        $request->pack_sale_status == "on" ? $request->pack_sale_status = 1 : $request->pack_sale_status = 0;
        $request->isFreez == "on" ? $request->isFreez = 1 : $request->isFreez = 0;
        $request->isActive == "on" ? $request->isActive = 1 : $request->isActive = 0;
        $request->isMaterial == "on" ? $request->isMaterial = 1 : $request->isMaterial = 0;
        $request->set_price == "on" ? $request->set_price = 1 : $request->set_price = 0;
        $product->update([
            'orderLimit' => $request->orderLimit,
            'title' => $request->title,
            'sku' => $request->sku,
            'display_name' => $request->display_name,
            'description' => $request->description,
            'pr_unit' => $request->pr_unit,
            'pr_sub_unit' => $request->pr_sub_unit,
            'pack_items' => $request->pack_items,
            'pack_weight' => $request->pack_weight,
            'price' => str_replace(',', '', $request->price),
            'discount' => $request->discount != '' ? str_replace(',', '', $request->discount) : null,
            'tax' => $request->tax != '' ? str_replace(',', '', $request->tax) : null,
            'fee_masraf' => str_replace(',', '', $request->fee_masraf),
            'entity' => isset($Active_Depot) ? $Active_Depot->entity : 0,
            'orderLimit' => isset($Active_Depot) ? $Active_Depot->orderLimit : 0,
            'brand_id' => $request->brand_id,
            'parentCategory_id' => $request->parentCategory_id,
            'chaildCategory_id' => isset($request->chaildCategory_id) ? $request->chaildCategory_id : $product->chaildCategory_id,
            'isActive' => $request->isActive,
            'item_sale_status' => $request->item_sale_status,
            'pack_sale_status' => $request->pack_sale_status,
            'isFreez' => $request->isFreez,
            'isMaterial' => $request->isMaterial,
            'set_price' => $request->set_price,
            'depot_id' => intval($request->depot_id) > 0 ? $request->depot_id : null,
            'attrs' => isset($pr_attrs) ? json_encode($pr_attrs) : null,
            'store_id' => isset($request->store_id) ? $request->store_id : $product->store_id,
            'organization_id' => isset($request->organization_id) ? $request->organization_id : $product->organization_id,
            'updated_at' => now()
        ]);

        Product::withoutGlobalScopes()
            ->where('id', '!=', $product->id)
            ->where('sku', $product->sku)
            ->where('organization_id', $product->organization_id)
            ->where('store_id', $product->store_id)
            ->update([
                'isActive' => $product->isActive,
                'updated_at' => now(),
            ]);

        if ($request->hasFile('photo')) {
            $imageName = time() . '.' . $request->file('photo')->getClientOriginalExtension();
            $request->file('photo')->move('storage/uploads', $imageName);
            $product->update([
                'photo' => $imageName
            ]);
        }
        //Stores
        $user = \Auth::user();
        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'update',
            'description' => 'محصول ویرایش شد' . '-' . $product->title
        ]);

        if ($entity != $product->entity) {
            History::create([
                'ip' => $_SERVER['REMOTE_ADDR'],
                'user_id' => $user->id,
                'action' => 'editEntity',
                'store' => $product->store->title,
                'description' => " کالای " . $product->title . " از تعداد " . $entity . " به تعداد " . $product->entity . " تغییر یافت"
            ]);
        }


        Alert::success('تشکر', 'رکورد با موفقیت ویرایش شد');
        return redirect(asset('products'));
    }

    public function updateFees()
    {

        $user = \Auth::user();
        if ($user->isGod == 1) {
            $Products = Product::all();
        } else {

            $Products = Product::where('organization_id', $user->organization_id)->get();
        }

        return view('products.products-fees', compact('Products'));
    }

    public function update_product_fees(Request $request)
    {

        $user = auth()->user();
        //dd($request->all());

        foreach ($request->all() as $key => $value) {
            if ($value != null) {
                if (str_starts_with($key, 'pr_price_')) {
                    $id = str_replace('pr_price_', '', $key);
                    $price = str_replace(',', '', $value);
                    $PriceLog = new PriceLog();
                    $PriceLog->pr_id = $id;
                    $PriceLog->price = $price;
                    $PriceLog->user_id = $user->id;
                    $PriceLog->save();

                    $Product = Product::find($id);
                    $Product->price =  str_replace(',', '', $value);
                    $Product->save();

                    History::create([
                        'ip' => $_SERVER['REMOTE_ADDR'],
                        'user_id' => $user->id,
                        'action' => 'entity',
                        'store' => $Product->title . ' ' . $Product->display_name,
                        'description' => " برای کالای " . $Product->title . ' ' . $Product->display_name . "قیمت روز ثبت شد."
                    ]);
                }
            }
        }

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => 'به روزرسانی قیمت روز محصولات انجام شد'
        ]);



        Alert::success('تشکر', 'قیمت ها با موفقیت به روزرسانی شد.');
        return redirect(route('products.updateFees'));
    }

    public function notify(Product $product)
    {
        $product->update([
            'isNotify' => 0
        ]);
        return back();
    }

    public function getCategory($id)
    {
        $childCategory_id = Category::where('parent_id', $id)
            ->where('isActive', 1)->get();
        return response()->json($childCategory_id);
    }

    public function getprs($id)
    {

        $Category = Category::find($id);

        $name = str_replace(" ", "_", $Category->title);

        $url = "https://appdocs.daramino.ir/PRSApi/$name/";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $json = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($json);


        return response()->json($data->data);
    }

    public function getprInfo($title)
    {

        $title = str_replace(" ", "_", $title);
        $url = "https://appdocs.daramino.ir/GetPrInfo/$title/";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $json = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($json);


        return response()->json($data->data);
    }

    public function getStore($id)
    {
        $store_id = Store::where('organization_id', $id)
            ->where('isActive', 1)->get();
        return response()->json($store_id);
    }

    public function productsByStore($store)
    {


        $id = array();
        $Products = Product::whereJsonContains('products.store_id', $store)
            ->leftJoin('depots', function ($join) use ($store) {
                $join->on('products.id', '=', 'depots.pr_id')
                    ->where('depots.store_id', $store)
                    ->where('depots.status', 1);
            })
            ->select(
                'products.*',
                DB::raw('SUM(depots.entity) as total_entity'),
                DB::raw('SUM(depots.entity_sub_unit) as total_entity_sub_unit'),
                DB::raw('SUM(depots.entity) / NULLIF(products.pack_items, 0) as sub_unit_from_entity')
            )
            ->groupBy('products.id')
            ->get();


        return response()->json($Products);
    }

    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $product->delete();
        return back();
    }
}
