<?php

namespace App\Http\Controllers;

use App\Models\Accounts;
use App\Models\Log;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class AccountController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $user = \Auth::user();
        if($user->isGod == 1) {
            $Accounts = Accounts::all();
        }else {
            $Accounts = Accounts::where('tenants_id',$user->tenants_id)->get();
            $MainAccounts = Accounts::where('tenants_id',$user->tenants_id)->where('parent_id',0)->get();
        }

        return view('account.index',compact('Accounts','MainAccounts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //dd($request->all());
        $user = \Auth::user();
        $request['tenants_id'] = $user->tenants_id;
        $request['created_by'] = $user->id;
        $Account = Accounts::create($request->all());

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => 'حساب جدید ایجاد شد' . '-' . $request->name,
            'tenants_id' => $user->tenants_id,
        ]);

        Alert::success('تشکر', 'حساب جدید با موفقیت ایجاد شد');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $Account = Accounts::find($id);
        $user = \Auth::user();
        if($user->isGod == 1) {
            $Accounts = Accounts::all();
        }else {
            $Accounts = Accounts::where('tenants_id',$user->tenants_id)->get();
            $MainAccounts = Accounts::where('tenants_id',$user->tenants_id)->where('parent_id',0)->get();
        }

        return view('account.edit',compact('Account','Accounts','MainAccounts'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //dd($request->all());
        $Account = Accounts::find($id);
        $Account->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'level' => $request->level,
            'parent_id' => $request->parent_id,
            'type' => $request->type,
            'nature' => $request->nature,
            'account_number' => $request->account_number,
            'card_number' => $request->card_number,
            'iban' => $request->iban,
            'branch' => $request->branch,
        ]);

        Alert::success('تشکر', 'ویرایش حساب با موفقیت انجام شد.');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
