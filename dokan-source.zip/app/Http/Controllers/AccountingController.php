<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pishfactor;
use App\Models\PishFactorItems;
use App\Models\Product;
use Hekmatinasser\Verta\Verta;
use App\Models\Depot;
use Illuminate\Support\Facades\DB;


class AccountingController extends Controller
{
    public function __construct()
    {
        $this->middleware('can:Accounting,user')->only(['index', 'store', 'edit', 'update', 'destroy']);
    }

    public function index(Request $request)
    {

        $Products = Product::all();

        $day = verta()->format('Y/m/d');

        if($request->has('from_date') && $request->has('to_date')) {

            $fromDate = str_replace("/", "-", $request->get('from_date'));

            $jalaliFrom = explode("-", $fromDate);
            $miladiFrom = Verta::jalaliToGregorian($jalaliFrom[0],$jalaliFrom[1],$jalaliFrom[2]);
            $ymF = $miladiFrom[0];
            if(strlen($miladiFrom[1]) == 1) {
                $mmF = "0".$miladiFrom[1];
            }else {
                $mmF = $miladiFrom[1];
            };
            if(strlen($miladiFrom[2]) == 1) {
                $dmF = "0".$miladiFrom[2];
            }else {
                $dmF = $miladiFrom[2];
            };


            $toDate = str_replace("/", "-", $request->get('to_date'));

            $jalaliTo = explode("-", $toDate);
            $miladiTo = Verta::jalaliToGregorian($jalaliTo[0],$jalaliTo[1],$jalaliTo[2]);
            $ymT = $miladiTo[0];
            if(strlen($miladiTo[1]) == 1) {
                $mmT = "0".$miladiTo[1];
            }else {
                $mmT = $miladiTo[1];
            };
            if(strlen($miladiTo[2]) == 1) {
                $dmT = "0".$miladiTo[2];
            }else {
                $dmT = $miladiTo[2];
            };

            //$startDate = Carbon::createFromFormat('Y-m-d', $fromDate);
            //$endDate = Carbon::createFromFormat('Y-m-d', $toDate);

            $AllFactors = Pishfactor::whereIn('status',[1,4])->orderBy('id','desc')->get();
            $PishFactors =  Pishfactor::where('status', 1)
                ->whereBetween('recive_date_en', ["$ymF-$mmF-$dmF", "$ymT-$mmT-$dmT"])
                ->orderBy('id', 'desc')
                ->get();

        }else {
            $AllFactors = Pishfactor::whereIn('status',[1,4])->orderBy('id','desc')->get();
            $PishFactors = Pishfactor::whereIn('status',[1,4])->where('payment_type',1)->orderBy('id','desc')->get();
            $Checki = Pishfactor::whereIn('status',[1,4])->where('payment_type',2)->orderBy('id','desc')->get();
            $unpayed = Pishfactor::whereIn('status',[1,4])->whereNotIn('payment_type',[1,2])->orderBy('id','desc')->get();

            $fromDate = null;
            $toDate = null;
        }



        return view('Accounting.Fund', compact('PishFactors','Checki','unpayed','AllFactors','fromDate','toDate','Products'));

    }

    public function AccountingReviews() {
        
        return view('Accounting.AccountingReviews');
    }


    public function ProductsSales(Request $request)
    {
        $startDate   = $request->input('from_date') ? $this->toGregorianDate($request->input('from_date')) : null;
        $endDate     = $request->input('to_date') ? $this->toGregorianDate($request->input('to_date')) : null;

        $delivery_from_date = $request->input('delivery_from_date') ? $this->toGregorianDate($request->input('delivery_from_date')) : null;
        $delivery_to_date   = $request->input('delivery_to_date') ? $this->toGregorianDate($request->input('delivery_to_date')) : null;


        $user = \Auth::user();
        $products = Product::withoutGlobalScope('withCurrentStock') // حذف موجودی پیش‌فرض
        ->forOrganizations($user, 'products.organization_id')
            ->where('products.isMaterial', 0)
            ->withSalesReport(
                $this->toGregorianDate($request->input('from_date')),
                $this->toGregorianDate($request->input('to_date')),
                $this->toGregorianDate($request->input('delivery_from_date')),
                $this->toGregorianDate($request->input('delivery_to_date'))
            )
            ->get();

        return view('Accounting.productsList', compact('products'));
    }
    public function PrFilter(Request $request) {

        $Products = Product::all();

        $pr_id = $request->get('pr_id');
        $Product = Product::find($request->get('pr_id'));
        echo $Product->title." - ".$Product->display_name." <hr />";

        // گرفتن آی‌دی فاکتورهایی که این محصول را دارند
        $factorIds = PishFactorItems::where('pr_id', $request->get('pr_id'))
            ->pluck('pishfactor_id')
            ->unique()
            ->toArray();

        // فقط فاکتورهای مرتبط را بگیر
        $pishfactors = Pishfactor::whereIn('id', $factorIds)
            ->whereIn('status', [1, 4])
            ->get();

        // رکوردهای Depot با pr_id مورد نظر
        $depots = Depot::where('pr_id', $request->get('pr_id'))->get();

        // ترکیب هر دو کالکشن و سورت بر اساس created_at
        $merged = $pishfactors->concat($depots)->sortByDesc(function($item) {
            return $item->created_at;
        });

        // گروه‌بندی بر اساس روز و مرتب‌سازی صعودی تاریخ (قدیمی‌ترین اول)
        $grouped = $merged->groupBy(function($item) {
            return $item->created_at->format('Y-m-d');
        })->sortKeys();

        $CARDEX = array();
        $Cardex_item = array();
        foreach ($grouped as $date => $items) {
            // echo "<h3>".$date."</h3><ul>";
            $endate = explode("-", $date);
            $Jalali = Verta::GregorianToJalali($endate[0],$endate[1],$endate[2]);
            $export = 0;
            $import = 0;
            foreach ($items as $item) {
                // تشخیص نوع رکورد
                if ($item instanceof \App\Models\Pishfactor) {
                    $cur_item_info = PishFactorItems::where('pr_id', $request->get('pr_id'))->where('pishfactor_id',$item->id)->first();
                    $tedadkol = intval($cur_item_info->pack * $Product->pack_items) + intval($cur_item_info->tedad);
                    $export += $tedadkol;
                } else {
                    $import += $item->entity;
                }
            }
            if($import > 0) {
                // echo "<li>ورود: .$import.</li>";
                $Cardex_item['date'] = $Jalali[0]."/".$Jalali[1]."/".$Jalali[2];
                $Cardex_item['import'] = $import;
                $Cardex_item['export'] = 0;
                $Cardex_item['price'] = $item->price;
            }
            if($export > 0) {
                //  echo "<li>خروج: .$export.</li>";
                $Cardex_item['date'] = $Jalali[0]."/".$Jalali[1]."/".$Jalali[2];
                $Cardex_item['export'] = $export;
                $Cardex_item['import'] = 0;
                $Cardex_item['price'] = $cur_item_info->price;
            }

            array_push($CARDEX, $Cardex_item);


            //  echo "</ul>";
        }

        return view('Accounting.Report_cardex', compact('CARDEX','Products'));
    }

    public function payed() {

        $PishFactors = Pishfactor::whereIn('status',[1,4])->whereIn('payment_type',[1,2])->orderBy('id','desc')->get();

        return view('Accounting.index', compact('PishFactors'));

    }

    public function unpayed() {

        $PishFactors = Pishfactor::whereIn('status',[1,4])->whereIn('payment_type',[3,null])->orderBy('id','desc')->get();

        return view('Accounting.index', compact('PishFactors'));

    }

    private function toGregorianDate($jalaliDate) {
        // مثلا ورودی: 1403/07/01 یا 1403-07-01
        $jalaliDate = str_replace("/", "-", $jalaliDate);
        $parts = explode("-", $jalaliDate); // [سال, ماه, روز]
        if(count($parts) !== 3) return null;

        $miladi = \Verta::jalaliToGregorian($parts[0], $parts[1], $parts[2]);
        $year = $miladi[0];
        $month = str_pad($miladi[1], 2, "0", STR_PAD_LEFT);
        $day = str_pad($miladi[2], 2, "0", STR_PAD_LEFT);

        return "{$year}-{$month}-{$day}";
    }

}
