<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Store;
use App\Models\Depot;
use App\Models\Receipt;
use Illuminate\Http\Request;
use App\Models\Log;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;
use Hekmatinasser\Verta\Verta;
use App\Services\ReceiptAiService;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;


class ReceiptController extends Controller
{
    public function index() {
        $user = \Auth::user();
        if ($user->isGod == 1) {

            $Stores = Store::all();
        }else {
            $userOrgs = is_array(json_decode($user->organization_id))
                ? json_decode($user->organization_id)
                : [intval($user->organization_id)];

// تبدیل به آرایه‌ای از هم int هم string
            $searchValues = [];
            foreach ($userOrgs as $orgId) {
                $searchValues[] = intval($orgId);
                $searchValues[] = strval($orgId);
            }

            $Stores = Store::where(function($q) use ($searchValues) {
                foreach ($searchValues as $orgId) {
                    $q->orWhereJsonContains('organization_id', $orgId)  // استورها JSON باشن (int یا string)
                    ->orWhere('organization_id', $orgId);             // استورها عدد باشن
                }
            })->get();
        }


        return view('stocks.receipts', compact('Stores'));
    }

    public function storeReceipts(Store $store) {
        $user = \Auth::user();
        if ($user->isGod == 1 || $user->isAdmin == 1) {
            $Receipts = Receipt::where('store_id', $store->id)->get();
        }else {
            $Receipts = Receipt::where('store_id', $store->id)->where('user_id',$user->id)->get();
        }


        return view('stocks.storeReceipts', compact('Receipts','store'));

    }

    public function storeReceiptShow(Store $store,Receipt $receipt) {
        $user = \Auth::user();

        if ($user->isGod == 1) {
            $Stores = Store::all();
        }else {
            $Stores = Store::forOrganizations($user)->where('isActive',1)->get();
        }

        $Depots = Depot::where('receipt_id', $receipt->id)->get();
        $Products = Product::whereJsonContains('store_id',["$store->id"])->get();


        return view('stocks.importPageEdit', compact('Stores','store','receipt','Depots','Products'));
    }



    public function store(Request $request)
    {

        //dd($request->all());
        $user = \Auth::user();

        $request['user_id'] = $user->id;
        $Product = Product::find($request->pr_id);

        if ($request->date_fa != '') {
            $arrayDate = explode(" ", $request->get('date_fa'));
            $fromFaHustDate = $arrayDate[0];
            $jalaliFrom = explode("/", $fromFaHustDate);
            $miladiFrom = Verta::jalaliToGregorian($jalaliFrom[0], $jalaliFrom[1], $jalaliFrom[2]);
            $ymF = $miladiFrom[0];
            if (strlen($miladiFrom[1]) == 1) {
                $mmF = "0" . $miladiFrom[1];
            } else {
                $mmF = $miladiFrom[1];
            };
            if (strlen($miladiFrom[2]) == 1) {
                $dmF = "0" . $miladiFrom[2];
            } else {
                $dmF = $miladiFrom[2];
            };

            $dateEn = "$ymF-$mmF-$dmF 00:00:00";


        }else {
            $dateEn = null;
        }

        $request['date_en'] = $dateEn;
        $Receipt = Receipt::create($request->all());

        if($request->has('pr_id')) {
            $pr_ids = $request->get('pr_id');
            $units = $request->get('unit');
            $sub_units = $request->get('sub_unit');

            $x = 0;
            foreach($pr_ids as $pr_id) {
                $Depot = new Depot();
                $Depot->pr_id = $pr_id;
                $Depot->receipt_id = $Receipt->id;
                $Depot->entity = $units[$x];
                $Depot->entity_sub_unit = 0;
                $Depot->store_id = $request->store_id;
                $Depot->status = 1;
                $Depot->save();
                $x++;
            }

        }

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => "ثبت رسید جدید برای انبار"
        ]);

        Alert::success('تشکر', "رسید جدید با موفقیت ثبت گردید.");
        return back();
    }

    public function update(Request $request, Receipt $receipt)
    {
        /* ------------------------------------
           1. تاریخ
        ------------------------------------ */
        if ($request->date_fa != '') {
            $fromDate = str_replace("/", "-", $request->get('date_fa'));
            $jalaliFrom = explode("-", $fromDate);
            $miladiFrom = Verta::jalaliToGregorian(
                $jalaliFrom[0],
                $jalaliFrom[1],
                $jalaliFrom[2]
            );

            $date_en = sprintf(
                '%04d-%02d-%02d 00:00:00',
                $miladiFrom[0],
                $miladiFrom[1],
                $miladiFrom[2]
            );
        }

        /* ------------------------------------
           2. بروزرسانی رسید
        ------------------------------------ */
        $receipt->update([
            'type'      => $request->type,
            'store_id'  => $request->store_id,
            'input_id'  => $request->input_id,
            'date_fa'   => $request->date_fa,
            'sender'    => $request->sender,
            'moeen'     => $request->moeen,
            'driver'    => $request->driver,
            'tozihat'   => $request->tozihat,
            'updated_at'=> now()
        ]);

        if (isset($date_en) && $receipt->created_at != $date_en) {
            $receipt->update(['created_at' => $date_en]);
        }

        /* ------------------------------------
           3. ورودی‌های جدول
        ------------------------------------ */
        $prIds     = $request->get('pr_id', []);
        $units     = $request->get('unit', []);
        $subUnits  = $request->get('sub_unit', []);

        /* ------------------------------------
           4. حذف آیتم‌هایی که دیگر در جدول نیستند
        ------------------------------------ */
        Depot::where('receipt_id', $receipt->id)
            ->where('store_id', $receipt->store_id)
            ->whereNotIn('pr_id', array_filter($prIds))
            ->delete();

        /* ------------------------------------
           5. insert / update با حفظ ترتیب
        ------------------------------------ */
        foreach ($prIds as $index => $prId) {

            if (!$prId) continue;

            Depot::updateOrCreate(
                [
                    'receipt_id' => $receipt->id,
                    'store_id'   => $receipt->store_id,
                    'pr_id'      => $prId,
                ],
                [
                    'entity'      => $units[$index] ?? 0,
                    'order_index' => $index // ⭐ ترتیب
                ]
            );
        }

        /* ------------------------------------
           6. لاگ
        ------------------------------------ */
        $user = auth()->user();

        Log::create([
            'ip'          => request()->ip(),
            'user_id'     => $user->id,
            'action'      => 'update',
            'section'     => 'store',
            'description' => "سند انبار توسط {$user->name} ویرایش شد."
        ]);

        Alert::success('انجام شد', 'سند انبار با موفقیت ویرایش شد');

        return redirect()->route(
            'stocks.storeReceiptShow',
            ['store' => $receipt->store_id, 'receipt' => $receipt->id]
        );
    }


    public function storeTransfer(Request $request)
    {
        // dd($request->all());
        $user = \Auth::user();

        $request['user_id'] = $user->id;
        // Receipt type = 6 Store Transfer
        $Receipt = Receipt::create($request->all());

        $store_id  = $request->get('store_id');
        $to_store_id  = $request->get('to_store_id');
        $pr_ids = $request->get('pr_id');
        $units = $request->get('unit');
        $sub_units = $request->get('sub_unit');

        if($request->has('pr_id')) {
            $x = 0;
            foreach ($pr_ids as $pr_id) {
                // Depot for Export From Store
                $Depot = new Depot();
                $Depot->pr_id = $pr_id;
                $Depot->receipt_id = $Receipt->id;
                $Depot->entity = $units[$x];
                $Depot->entity_sub_unit = 0;
                $Depot->store_id = $store_id;
                $Depot->status = 0;
                $Depot->save();

                $Depot = new Depot();
                $Depot->pr_id = $pr_id;
                $Depot->receipt_id = $Receipt->id;
                $Depot->entity = $units[$x];
                $Depot->entity_sub_unit = 0;
                $Depot->store_id = $to_store_id;
                $Depot->status = 1;
                $Depot->save();
                $x++;
            }
        }

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => "ثبت رسید جدید برای انبار"
        ]);

        Alert::success('ثبت انتقال', "انتقال بین انبار با موفقیت انجام شد.");
        return back();


    }


    public function importReceiptAi(Request $request, ReceiptAiService $service)
    {
        try {
            /* ---------- VALIDATION ---------- */
            $request->validate([
                'receipt_photo' => [
                    'required',
                    'image',
                    'mimes:jpg,jpeg,png,webp',
                    'max:8192',
                ],
            ]);

            /* ---------- ABSOLUTE PATH ---------- */
            $uploadDir = '/home/darami/public_html/newdokan/storage/receipts_ai';

            if (!is_dir($uploadDir)) {
                throw new \Exception('Upload directory does not exist');
            }

            if (!is_writable($uploadDir)) {
                throw new \Exception('Upload directory is not writable');
            }

            /* ---------- SAFE FILENAME ---------- */
            $file = $request->file('receipt_photo');

            $filename = Str::uuid()->toString() . '.' . $file->getClientOriginalExtension();

            /* ---------- MOVE FILE ---------- */
            $file->move($uploadDir, $filename);

            /* ---------- PUBLIC URL ---------- */
            $imageUrl = url("/storage/receipts_ai/{$filename}");

            /* ---------- PROCESS AI ---------- */
            $result = app(ReceiptAiService::class)
                ->processImage($imageUrl);

            return response()->json($result);


        } catch (\Illuminate\Validation\ValidationException $e) {

            return response()->json([
                'success' => false,
                'errors'  => $e->errors(),
            ], 422);

        } catch (\Throwable $e) {

            return response()->json([
                'success' => false,
                'error'   => $e->getMessage(),
            ], 500);
        }
    }


    public function deleteReceipt(Request $request, Receipt $receipt)
    {

        $user = \Auth::user();
        $Store = Store::find($receipt->store_id);
        $Storetitle = $Store->title;
        $Depots = Depot::where('receipt_id', $receipt->id)->delete();
        $Num = $receipt->number;
        $receipt->delete();

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => "حذف رسید شماره $Num برای انبار $Storetitle    برای انبار"
        ]);

        Alert::success('حذف موفق', "رسید مورد نظر حذف شذ.");
        return redirect()->back();


    }




}
