<?php

namespace App\Http\Controllers;

use App\Models\Log;
use App\Models\Tenants;
use App\Models\Organization;
use App\Models\Role;
use App\Models\User;
use App\Models\Cargo;
use App\Models\Store;
use App\Models\Pishfactor;
use App\Models\Targets;
use App\Models\Tasks;
use App\Models\Customers;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;
use Hekmatinasser\Verta\Verta;
use Kavenegar;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('can:users,user')->only(['index', 'store', 'edit', 'update', 'destroy', 'trashGet', 'trashPost', 'restore']);
    }

    public function index()
    {
        $User = auth()->user();
        $leader_role = Role::where('title', 'leader')->first();
        $expert_role = Role::where('title', 'expert')->first();
        $leader_Users = DB::table('role_user')->whereIn('role_id', [$leader_role->id, $expert_role->id])->pluck('user_id')->toArray();
        if ($User->isGod == 1) {
            $users = User::all();
            $Leaders = User::whereIn('id', $leader_Users)->get();
            $organizations = Organization::all();
            $deactive_users = User::where('isActive', 0)->get();
            $active_users = User::where('isActive', 1)->get();
        } elseif ($User->isGod == 0 && $User->isAdmin == 1) {
            $users = User::forOrganizations($User)->get();
            $Leaders = User::whereIn('id', $leader_Users)->forOrganizations($User)->get();
            $organizations = Organization::forOrganizations($User, 'id')->get();
            $deactive_users = User::forOrganizations($User)->where('isActive', 0)->get();
            $active_users = User::forOrganizations($User)->where('isActive', 1)->get();
        } else {
            $users = User::forOrganizations($User)->get();
            $Leaders = User::whereIn('id', $leader_Users)->forOrganizations($User)->get();
            $organizations = Organization::forOrganizations($User, 'id')->get();
            $deactive_users = User::forOrganizations($User)->where('isActive', 0)->get();
            $active_users = User::forOrganizations($User)->where('isActive', 1)->get();
        }
        $roles = Role::all();

        return view('users.index', compact('users', 'roles', 'organizations', 'Leaders', 'deactive_users', 'active_users'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'mobile' => ['required', 'string', 'max:20', 'unique:users,mobile'],
            'password' => ['required', 'string', 'min:6'],
            'organization_id' => ['required'],
            'role_id' => ['required'],
        ], [
            'name.required' => 'نام کاربر الزامی است.',
            'email.required' => 'ایمیل کاربر الزامی است.',
            'email.email' => 'فرمت ایمیل صحیح نیست.',
            'email.unique' => 'کاربری با این ایمیل قبلا ثبت شده است.',
            'mobile.required' => 'شماره همراه کاربر الزامی است.',
            'mobile.unique' => 'کاربری با این شماره همراه قبلا ثبت شده است.',
            'password.required' => 'رمز عبور کاربر الزامی است.',
            'password.min' => 'رمز عبور باید حداقل 6 کاراکتر باشد.',
            'organization_id.required' => 'انتخاب شعبه الزامی است.',
            'role_id.required' => 'انتخاب نقش کاربری الزامی است.',
        ]);

        $currentUser = auth()->user();
        $canChooseTenant = $currentUser->isGod == 1 || strcasecmp((string) $currentUser->email, 'admin@almas.com') === 0;
        $organizationId = $canChooseTenant ? $request->organization_id : $currentUser->organization_id;
        $tenantId = $canChooseTenant ? $request->tenants_id : $currentUser->tenants_id;

        if ($organizationId) {
            $organization = Organization::find($organizationId);
            if ($organization) {
                $tenantId = $organization->tenants_id;
            }
        }

        $user = User::create([
            'name' => $request->name,
            'personalID' => $request->password,
            'email' => $request->email,
            'mobile' => $request->mobile,
            'tenants_id' => $tenantId,
            'organization_id' => $organizationId,
            'leader_id' => $request->leader_id,
            'password' => bcrypt($request->password)
        ]);
        $user->roles()->sync($request->role_id);

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => \Auth::user()->id,
            'action' => 'create',
            'description' => 'یک کاربر ایجاد شد' . '-' . $user->name
        ]);

        try {
            $receptor = $user->mobile;
            $token = "$user->email";
            $token2 = "$request->password";
            $token3 = "";
            $template = "UserWelcome";
            //Send null for tokens not defined in the template
            //Pass token10 and token20 as parameter 6th and 7th
            $result = Kavenegar::VerifyLookup($receptor, $token, $token2, $token3, $template, $type = null);
            if ($result) {
                foreach ($result as $r) {
                    echo "messageid = $r->messageid";
                    echo "message = $r->message";
                    echo "status = $r->status";
                    echo "statustext = $r->statustext";
                    echo "sender = $r->sender";
                    echo "receptor = $r->receptor";
                    echo "date = $r->date";
                    echo "cost = $r->cost";
                }
            }
        } catch (\Kavenegar\Exceptions\ApiException $e) {
            // در صورتی که خروجی وب سرویس 200 نباشد این خطا رخ می دهد
            echo $e->errorMessage();
        } catch (\Kavenegar\Exceptions\HttpException $e) {
            // در زمانی که مشکلی در برقرای ارتباط با وب سرویس وجود داشته باشد این خطا رخ می دهد
            echo $e->errorMessage();
        }

        if ($request->has('leader_id') && $request->leader_id != null) {


            try {
                $Leader = User::find($request->leader_id);
                $receptor = $Leader->mobile;
                $token = str_replace(" ", "_", $user->name);
                $token2 = "";
                $token3 = "";
                $template = "LeaderNotif";
                //Send null for tokens not defined in the template
                //Pass token10 and token20 as parameter 6th and 7th
                $result = Kavenegar::VerifyLookup($receptor, $token, $token2, $token3, $template, $type = null);
                if ($result) {
                    foreach ($result as $r) {
                        echo "messageid = $r->messageid";
                        echo "message = $r->message";
                        echo "status = $r->status";
                        echo "statustext = $r->statustext";
                        echo "sender = $r->sender";
                        echo "receptor = $r->receptor";
                        echo "date = $r->date";
                        echo "cost = $r->cost";
                    }
                }
            } catch (\Kavenegar\Exceptions\ApiException $e) {
                // در صورتی که خروجی وب سرویس 200 نباشد این خطا رخ می دهد
                echo $e->errorMessage();
            } catch (\Kavenegar\Exceptions\HttpException $e) {
                // در زمانی که مشکلی در برقرای ارتباط با وب سرویس وجود داشته باشد این خطا رخ می دهد
                echo $e->errorMessage();
            }
        }

        Alert::success('تشکر', 'رکورد با موفقیت ایجاد شد');
        return back();
    }

    public function edit(User $user)
    {

        $Tenants = Tenants::all();
        $users = User::all();
        $roles = Role::all();
        $userEdit = $user;

        $leader_role = Role::where('title', 'leader')->first();
        $expert_role = Role::where('title', 'expert')->first();
        $leader_Users = DB::table('role_user')->whereIn('role_id', [$leader_role->id, $expert_role->id])->pluck('user_id')->toArray();
        $Leaders = User::whereIn('id', $leader_Users)->get();

        $role = $user->roles()->first();
        $roleTitle = $role ? $role->title : '-';
        $UserFactors = $this->getUserFactors($user->id, $roleTitle, null, null);

        if (auth()->user()->isGod == 1) {
            $Stores = Store::all();
            $organizations = Organization::all();
        } else {
            $Stores = Store::forOrganizations(auth()->user())->get();
            $organizations = Organization::forOrganizations(auth()->user(), 'id')->get();
        }


        return view('users.edit', compact('users', 'userEdit', 'roles', 'organizations', 'Leaders', 'Tenants', 'UserFactors', 'Stores'));
    }

    public function updateU(Request $request, User $user)
    {


        $orgId = $request->input('organization_id');

        if (is_array($orgId) && count($orgId) === 1) {
            $request->organization_id = reset($orgId);
        }


        $Role = Role::find($request->role_id);

        $request->isActive == "on" ? $request->isActive = 1 : $request->isActive = 0;
        if ($request->has('tenants_id')) {
            $user->update([
                'tenants_id' => $request->tenants_id
            ]);
        }
        $user->update([
            'name' => $request->name,
            'personalID' => $request->password,
            'username' => $request->username,
            'email' => $request->email,
            'mobile' => $request->mobile,
            'organization_id' => $request->organization_id,
            'leader_id' => $request->leader_id,
            'isActive' => $request->isActive
        ]);
        if ($request->password != null) {
            $user->update([
                'password' => bcrypt($request->password)
            ]);
        }

        if ($user->leader_id != $request->leader_id) {

            try {
                $Leader = User::find($request->leader_id);
                $receptor = $Leader->mobile;
                $token = str_replace(" ", "_", $user->name);
                $token2 = "";
                $token3 = "";
                $template = "LeaderNotif";
                //Send null for tokens not defined in the template
                //Pass token10 and token20 as parameter 6th and 7th
                $result = Kavenegar::VerifyLookup($receptor, $token, $token2, $token3, $template, $type = null);
                if ($result) {
                    foreach ($result as $r) {
                        echo "messageid = $r->messageid";
                        echo "message = $r->message";
                        echo "status = $r->status";
                        echo "statustext = $r->statustext";
                        echo "sender = $r->sender";
                        echo "receptor = $r->receptor";
                        echo "date = $r->date";
                        echo "cost = $r->cost";
                    }
                }
            } catch (\Kavenegar\Exceptions\ApiException $e) {
                // در صورتی که خروجی وب سرویس 200 نباشد این خطا رخ می دهد
                echo $e->errorMessage();
            } catch (\Kavenegar\Exceptions\HttpException $e) {
                // در زمانی که مشکلی در برقرای ارتباط با وب سرویس وجود داشته باشد این خطا رخ می دهد
                echo $e->errorMessage();
            }
        }
        // $userEdit->roles()->sync($request->role_id,$userEdit->id);
        DB::table('role_user')
            ->where('user_id', $user->id)
            ->update(['role_id' => $request['role_id']]);


        if ($Role->title == 'driver') {
            $box_count_driver = $request->box_count_driver;
            $weight_count_driver = $request->weight_count_driver;


            $Cargo = Cargo::updateOrCreate(
                ['driver_id' => $user->id],
                [
                    'cartons'        => $box_count_driver,
                    'weight'  => $weight_count_driver,
                ]
            );
        }


        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => \Auth::user()->id,
            'action' => 'update',
            'description' => 'کاربر ویرایش شد' . '-' . $user->name
        ]);

        Alert::success('تشکر', 'رکورد با موفقیت ویرایش شد');
        return back();
    }



    public function profile() {}

    public function profileUpdate() {}

    private function getSubUsersWithFactors($leaderId, $start, $end)
    {
        $subs = User::where('leader_id', $leaderId)->get();
        $result = [];
        $AllFactorPrices = 0;
        foreach ($subs as $sub) {
            // گرفتن رول یوزر (فرض بر این است که relation roles تعریف شده)
            $role = $sub->roles()->first();
            $roleTitle = $role ? $role->title : '-';

            if ($roleTitle == 'leader') {
                // گرفتن تعداد فاکتورهای یوزر
                if ($start != null && $end != null) {
                    $factorsCount = Pishfactor::where('sarparast_id', $sub->id)
                        ->whereBetween('created_at', [$start, $end])
                        ->get();
                } else {
                    $factorsCount = Pishfactor::where('sarparast_id', $sub->id)->get();
                }
            }

            if ($roleTitle == 'visitor') {
                // گرفتن تعداد فاکتورهای یوزر
                if ($start != null && $end != null) {
                    $factorsCount = Pishfactor::where('visitor_id', $sub->id)
                        ->whereBetween('created_at', [$start, $end])
                        ->get();
                } else {
                    $factorsCount = Pishfactor::where('visitor_id', $sub->id)->get();
                }
            }
            $FactorPrices = 0;
            foreach ($factorsCount as $factor) {
                $FactorPrices += intval(str_replace(',', '', $factor->fullPrice));
            }
            $AllFactorPrices += $FactorPrices;



            // بازگشتی برای زیرمجموعه‌ها
            $children = $this->getSubUsersWithFactors($sub->id, $start, $end);

            $result[] = [
                'id' => $sub->id,
                'name' => $sub->name,
                'role' => $roleTitle,
                'factors_count' => count($factorsCount),
                'factors' => $factorsCount,
                'children' => $children,
                'FactorPrices' => $FactorPrices
            ];
        }

        // سورت بر اساس تعداد فاکتور
        usort($result, function ($a, $b) {
            return $b['factors_count'] <=> $a['factors_count'];
        });

        return $result;
    }

    private function getUserFactors($userId, $role, $start, $end)
    {

        $AllFactorPrices = 0;

        if ($role == 'leader') {
            if ($start != null && $end != null) {
                $factorsCount = Pishfactor::where('sarparast_id', $userId)
                    ->whereBetween('created_at', [$start, $end])
                    ->get();
            } else {
                $factorsCount = Pishfactor::where('sarparast_id', $userId)->get();
            }
        } elseif ($role == 'visitor') {
            if ($start != null && $end != null) {
                $factorsCount = Pishfactor::where('visitor_id', $userId)
                    ->whereBetween('created_at', [$start, $end])
                    ->get();
            } else {
                $factorsCount = Pishfactor::where('visitor_id', $userId)->get();
            }
        } else {
            $factorsCount = 0;
            $AllFactorPrices = 0;
        }

        $result = array(
            'factors_count' => is_array($factorsCount) ? count($factorsCount) : 0,
            'factors' => $factorsCount,
            'FactorPrices' => $AllFactorPrices
        );

        return $result;
    }

    public function userInvoiceList(Request $request, User $user)
    {
        $roleTitles = $user->roles->pluck('title')->all();
        $isVisitor = in_array('visitor', $roleTitles);
        $isLeader = in_array('leader', $roleTitles);
        $isManager = in_array('expert', $roleTitles);
        $hasOrganizationAccess = $isManager || $user->isAdmin == 1 || $user->isGod == 1;

        $Target = Targets::where('status', 1)->where('user_id', $user->id)->first();

        $MyTasks = collect();
        $AllFactors = collect();
        $AllFactorCount = 0;
        $AllFactorPrices = 0;
        $AcceptedFactorFullPrices = 0;
        $CompletedFactorFullPrices = 0;

        if ($isLeader) {
            $baseFactorsQuery = Pishfactor::where('sarparast_id', $user->id)
                ->whereIn('status', [1, 4]);

            $MyTasks = Tasks::where('leader_id', $user->id)->where('status', 1)->get();
        } elseif ($isVisitor) {
            $baseFactorsQuery = Pishfactor::where('visitor_id', $user->id)
                ->whereIn('status', [1, 4]);

            $MyTasks = Tasks::where('user_id', $user->id)->where('status', 1)->get();
        } elseif ($hasOrganizationAccess) {
            $baseFactorsQuery = Pishfactor::forOrganizations($user)
                ->whereIn('status', [1, 4]);
        } else {
            $baseFactorsQuery = Pishfactor::whereIn('status', [1, 4])
                ->whereRaw('1 = 0');
        }

        $PishFactors = clone $baseFactorsQuery;
        if ($Target) {
            $PishFactors->whereBetween('created_at', [$Target->start_date_en, Carbon::today()]);
        }

        $AllFactorsQuery = clone $baseFactorsQuery;
        if ($Target) {
            $AllFactorsQuery->whereBetween('created_at', [$Target->start_date_en, $Target->end_date_en]);
        }
        $AllFactors = $AllFactorsQuery->get();
        $AllFactorCount = $AllFactors->count();
        $AllFactorPrices = $AllFactors->sum(function ($item) {
            return (float) str_replace(',', '', $item->fullPrice);
        });

        $acceptedFactorsQuery = clone $baseFactorsQuery;
        $acceptedFactorsQuery->where('status', 1);
        if ($Target) {
            $acceptedFactorsQuery->whereBetween('created_at', [$Target->start_date_en, $Target->end_date_en]);
        }
        $AcceptedFactorFullPrices = $acceptedFactorsQuery->get()->sum(function ($item) {
            return (float) str_replace(',', '', $item->fullPrice);
        });

        $completedFactorsQuery = clone $baseFactorsQuery;
        $completedFactorsQuery->where('status', 4);
        if ($Target) {
            $completedFactorsQuery->whereBetween('created_at', [$Target->start_date_en, $Target->end_date_en]);
        }
        $CompletedFactorFullPrices = $completedFactorsQuery->get()->sum(function ($item) {
            return (float) str_replace(',', '', $item->fullPrice);
        });

        // =====================
        // فیلتر بر اساس تاریخ ایجاد فاکتور
        // =====================
        if ($request->from_date && $request->to_date) {
            $fromDate = str_replace("/", "-", $request->get('from_date'));
            $jalaliFrom = explode("-", $fromDate);
            $miladiFrom = Verta::jalaliToGregorian($jalaliFrom[0], $jalaliFrom[1], $jalaliFrom[2]);
            $ymF = $miladiFrom[0];
            $mmF = strlen($miladiFrom[1]) == 1 ? "0" . $miladiFrom[1] : $miladiFrom[1];
            $dmF = strlen($miladiFrom[2]) == 1 ? "0" . $miladiFrom[2] : $miladiFrom[2];

            $toDate = str_replace("/", "-", $request->get('to_date'));
            $jalaliTo = explode("-", $toDate);
            $miladiTo = Verta::jalaliToGregorian($jalaliTo[0], $jalaliTo[1], $jalaliTo[2]);
            $ymT = $miladiTo[0];
            $mmT = strlen($miladiTo[1]) == 1 ? "0" . $miladiTo[1] : $miladiTo[1];
            $dmT = strlen($miladiTo[2]) == 1 ? "0" . $miladiTo[2] : $miladiTo[2];

            $PishFactors->whereBetween('created_at', ["$ymF-$mmF-$dmF 00:00:00", "$ymT-$mmT-$dmT 23:59:59"]);
        }

        // =====================
        // فیلتر بر اساس تاریخ تحویل فاکتور
        // =====================
        if ($request->delivery_from_date && $request->delivery_to_date) {
            $fromDate = str_replace("/", "-", $request->get('delivery_from_date'));
            $jalaliFrom = explode("-", $fromDate);
            $miladiFrom = Verta::jalaliToGregorian($jalaliFrom[0], $jalaliFrom[1], $jalaliFrom[2]);
            $ymF = $miladiFrom[0];
            $mmF = strlen($miladiFrom[1]) == 1 ? "0" . $miladiFrom[1] : $miladiFrom[1];
            $dmF = strlen($miladiFrom[2]) == 1 ? "0" . $miladiFrom[2] : $miladiFrom[2];

            $toDate = str_replace("/", "-", $request->get('delivery_to_date'));
            $jalaliTo = explode("-", $toDate);
            $miladiTo = Verta::jalaliToGregorian($jalaliTo[0], $jalaliTo[1], $jalaliTo[2]);
            $ymT = $miladiTo[0];
            $mmT = strlen($miladiTo[1]) == 1 ? "0" . $miladiTo[1] : $miladiTo[1];
            $dmT = strlen($miladiTo[2]) == 1 ? "0" . $miladiTo[2] : $miladiTo[2];

            $PishFactors->whereBetween('recive_date_en', ["$ymF-$mmF-$dmF 00:00:00", "$ymT-$mmT-$dmT 23:59:59"]);
        }

        // در نهایت کوئری اجرا شود
        $PishFactors = $PishFactors->get();

        // محاسبه جمع قیمت‌ها
        $totalPrice = $AllFactors->sum(function ($item) {
            return (float)str_replace(',', '', $item->fullPrice);
        });

        $cur_user = $user;
        return view('users.invoiceList', compact('PishFactors', 'AllFactors', 'totalPrice', 'isVisitor', 'isLeader', 'cur_user', 'MyTasks', 'AllFactorCount', 'Target', 'AllFactorPrices', 'AcceptedFactorFullPrices', 'CompletedFactorFullPrices'));
    }

    public function destroy(User $user)
    {

        $me = \Auth::user();

        $user->delete();
        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $me->id,
            'action' => 'delete',
            'description' => 'کاربر حذف شد' . '-' . $user->name
        ]);

        Alert::success('تشکر', 'کاربر با موفقیت حذف شد');
        return redirect()->route('users.index');
    }
}
