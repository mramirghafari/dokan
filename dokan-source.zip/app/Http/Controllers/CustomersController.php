<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProductRequest;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\Customers;
use App\Models\Brand;
use App\Models\History;
use App\Models\Log;
use App\Models\Organization;
use App\Models\Store;
use App\Models\City;
use App\Models\Region;
use App\Models\Area;
use App\Models\Tasks;
use App\Models\Role;
use App\Models\Pishfactor;
use Auth;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class CustomersController extends Controller
{
    public function __construct()
    {
        $this->middleware('can:customers,user')->only(['index', 'destroy', 'trashGet', 'trashPost', 'restore']);
        $this->middleware('can:customers-add,user')->only(['create', 'store', 'edit', 'update']);
        $this->middleware('can:customers-edit,user')->only([ 'edit', 'update']);
    }

    public function index()
    {
        $user = \Auth::user();

        // تشخیص نقش‌ها با Collection به جای foreach
        $roleTitles = $user->roles->pluck('title')->toArray();
        $isManager = in_array('expert', $roleTitles);
        $isLeader  = in_array('leader', $roleTitles);
        $isVisitor = in_array('visitor', $roleTitles);

        if ($user->isGod == 1) {
            $Cities = City::all();
            $visitorRole = Role::where('title','visitor')->first();
            $VisitorUsers = DB::table('role_user')->where('role_id', $visitorRole->id)->pluck('user_id')->toArray();
            $Visitors = User::whereIn('id',$VisitorUsers)->where('leader_id',$user->id)->where('isActive',1)->get();

            $leaderRole = Role::where('title','leader')->first();
            $LeaderUsers = DB::table('role_user')->where('role_id', $leaderRole->id)->pluck('user_id')->toArray();
            $Leaders = User::whereIn('id',$LeaderUsers)->where('leader_id',$user->id)->where('isActive',1)->get();
            $Regions = Region::all();
        }elseif ($user->isAdmin == 1) {

            $Cities = City::forOrganizations($user)->get();
            $Driver_per = DB::table('roles')->where('title', 'driver')->first();
            $Drivers_ids = DB::table('role_user')->where('role_id', $Driver_per->id)->pluck('user_id');
            $Drivers = User::whereIn('id', $Drivers_ids)->forOrganizations($user)->get();

            $visitorRole = Role::where('title','visitor')->first();
            $VisitorUsers = DB::table('role_user')->where('role_id', $visitorRole->id)->pluck('user_id')->toArray();
            $Visitors = User::whereIn('id',$VisitorUsers)->where('leader_id',$user->id)->where('isActive',1)->get();

            $leaderRole = Role::where('title','leader')->first();
            $LeaderUsers = DB::table('role_user')->where('role_id', $leaderRole->id)->pluck('user_id')->toArray();
            $Leaders = User::whereIn('id',$LeaderUsers)->where('leader_id',$user->id)->where('isActive',1)->get();
            $Regions = Region::forOrganizations($user)->get();
        }else {
            $Cities = City::all();
            $visitorRole = Role::where('title','visitor')->first();
            $VisitorUsers = DB::table('role_user')->where('role_id', $visitorRole->id)->pluck('user_id')->toArray();
            $Visitors = User::whereIn('id',$VisitorUsers)->where('leader_id',$user->id)->where('isActive',1)->get();

            $leaderRole = Role::where('title','leader')->first();
            $LeaderUsers = DB::table('role_user')->where('role_id', $leaderRole->id)->pluck('user_id')->toArray();
            $Leaders = User::whereIn('id',$LeaderUsers)->where('leader_id',$user->id)->where('isActive',1)->get();
            $Regions = Region::forOrganizations($user)->get();

        }


        // آماده‌سازی Query اصلی (بدون get برای کنترل بهتر)
        $query = Customers::query()
            ->with(['region', 'Area', 'leader']) // روابط لازم برای جلوگیری از N+1
            ->withCount('activeOrders')          // شمار سفارش‌ها
            ->withSum('activeOrders', 'fullPrice'); // جمع مبلغ سفارش‌ها

        // سطح دسترسی
        if ($user->isGod == 1) {
            // خدا (همه داده‌ها)
        } elseif ($isLeader) {
            // لیدر: فیلتر مناطق زیرمجموعه
            $regionIds = Region::where('leader_id', $user->id)->pluck('id');
            $areaIds   = Area::whereIn('region_id', $regionIds)->pluck('id');
            $query->whereIn('area', $areaIds);
        } else {
            // سایر نقش‌ها: فیلتر سازمانی
            $query = Customers::forOrganizations($user)
                ->with(['region', 'Area', 'leader'])
                ->withCount('activeOrders')
                ->withSum('activeOrders', 'fullPrice');
        }

        // اعمال صفحه‌بندی برای کاهش بار حافظه و DOM
        $Customers = $query->orderBy('id', 'desc')->get();

        // تعداد مشتریانی که خرید کرده‌اند
        $customersWithPurchaseCount = Pishfactor::distinct('customer_id')->count('customer_id');

        $codename = null;
        $area_id = null;
        $leader_id = null;
        $visitor_id = null;
        $status = null;

        return view('customers.index', compact('Customers', 'customersWithPurchaseCount','Cities','Leaders','Visitors','Regions','codename','area_id','leader_id','visitor_id','status'));
    }

    public function create()
    {

        $user = \Auth::user();
        $roles = Role::all();
        $isManager = false;
        foreach ($user->roles as $role) {
            if($role->title == 'visitor') {
                $isVisitor = true;
            }else {
                $isVisitor = false;
            }
            if($role->title == 'expert') {
                $isManager = true;
            }
        }

        if($user->isAdmin == 1) {
            $Regions = Region::forOrganizations($user)->get();
            $Areas = null;
        }elseif($isManager) {
            $Regions = Region::forOrganizations($user)->get();
            $Areas = null;
        }else{
            $Regions = Region::where('leader_id',$user->id)->get();
            $Areas = null;
        }

        if($isVisitor) {
            $regionIds = Tasks::where('user_id', auth()->id())
                ->where('status', 1)
                ->whereHas('area.region') // شرط اینکه ناحیه و ریجن وجود داشته باشند
                ->with('area.region')     // برای جلوگیری از N+1
                ->get()
                ->pluck('area.region_id') // استخراج region_id از رابطه‌ها
                ->unique()                // حذف شناسه‌های تکراری
                ->values();               // مرتب‌سازی ایندکس‌ها
            $MyTasks = Tasks::where('user_id', auth()->user()->id)->where('status',1)->get();
            $areaIds = Tasks::where('user_id', auth()->user()->id)->where('status',1)->pluck('area_id')->unique();
            $Regions = Region::whereIn('id',$regionIds)->get();
            $Areas = Area::whereIn('id',$areaIds)->get();
        }else {
            $MyTasks = null;
            $Areas = null;
        }

        session()->put('backlink', asset('/customers'));
        return view('customers.create', compact('Regions','isVisitor','MyTasks','Areas'));
    }

    public function show($Customer,$task = null) {
        $Customer = Customers::find($Customer);
        if($task != null) {
            $MyTask = Tasks::find($task);
        }else {
            $MyTask = null;
        }
        $Factors = Pishfactor::where('customer_id', $Customer->id)->get();
        $FactorsAccepted = Pishfactor::where('customer_id', $Customer->id)->whereIn('status',[1,4])->get();
        $FactorsPriceCount = 0;
        foreach ($FactorsAccepted as $factor) {
            $price = intval(str_replace(',', '', $factor->fullPrice));
            $FactorsPriceCount += $price;
        }
        //$FactorsPriceCount = Pishfactor::where('customer_id', $id)->sum('fullPrice');

        session()->put('backlink', asset('/customers'));
        return view('customers.show', compact('Customer','Factors','FactorsPriceCount','FactorsAccepted','MyTask'));
    }

    public function search(Request $request)
    {
        $user = \Auth::user();

        // نقش‌های کاربر فعلی
        $roleTitles = $user->roles->pluck('title')->toArray();
        $isManager = in_array('expert', $roleTitles);
        $isLeader  = in_array('leader', $roleTitles);
        $isVisitor = in_array('visitor', $roleTitles);

        // بازیابی لیست‌ها بر اساس نقش و سازمان کاربر
        if ($user->isGod == 1) {
            $Visitors = User::whereHas('roles', fn($q) => $q->where('title', 'visitor'))->get();
            $Leaders  = User::whereHas('roles', fn($q) => $q->where('title', 'leader'))->get();
            $Regions  = Region::all();
            $Cities   = City::all();
        } else {
            // 🔸 فقط داده‌های مربوط به سازمان خودش
            $Visitors = User::whereHas('roles', fn($q) => $q->where('title', 'visitor'))
                ->where('organization_id', $user->organization_id)
                ->get();

            $Leaders = User::whereHas('roles', fn($q) => $q->where('title', 'leader'))
                ->where('organization_id', $user->organization_id)
                ->get();

            // 🔹 تغییر مهم (بازگشت به منطق اصلی تو)
            $Regions = Region::forOrganizations($user)->get();
            $Cities  = City::forOrganizations($user)->get();
        }


        if($request->isMethod('post')) {
            // ---------- شروع کوئری اصلی ----------
            $query = Customers::query()
                ->with(['region', 'Area', 'leader'])
                ->forOrganizations($user); // 🔸 هر سازمان فقط مشتریان خودش را می‌بیند



            // --- فیلتر نام یا کد مشتری ---
            if ($request->filled('codename')) {
                $codename = $request->codename;
                $term = trim($request->codename);
                $query->where(function ($q) use ($term) {
                    $q->where('name', 'LIKE', "%{$term}%")
                        ->orWhere('customer_code', 'LIKE', "%{$term}%");
                });
            }else {
                $codename = null;
            }

            // --- فیلتر بر اساس Area ---
            if (!empty($request->area_id) && $request->area_id != 0) {
                $area_id = $request->area_id;
                $query->where('area', $request->area_id);
            }else {
                $area_id = null;
            }

            // --- فیلتر بر اساس Leader ---
            if (!empty($request->leader_id) && $request->leader_id != 0) {
                $leader_id = $request->leader_id;
                $regionIds = Region::where('leader_id', $request->leader_id)->pluck('id');
                $areaIds = Area::whereIn('region_id', $regionIds)->pluck('id');
                $query->whereIn('area', $areaIds);
            }else {
                $leader_id = null;
            }

            // --- فیلتر بر اساس Visitor ---
            if (!empty($request->visitor_id) && $request->visitor_id != 0) {
                $visitor_id = $request->visitor_id;
                $areaIds = Tasks::where('user_id', $request->visitor_id)->pluck('area_id')->unique();
                $query->whereIn('area', $areaIds);
            }else {
                $visitor_id = null;
            }

            // --- فیلتر فقط مشتری‌های دارای خرید (status=1) ---
            if (!empty($request->status) && $request->status == 1) {
                $status = 1;
                $visitorId = $request->visitor_id ?? null;
                $query->whereHas('pishfactors', function ($q) use ($visitorId) {
                    $q->whereIn('status', [1, 4]);
                    if ($visitorId) {
                        $q->where('visitor_id', $visitorId);
                    }
                });
            }else {
                $status = 2;
            }

            // اجرای نهایی
            $Customers = $query->orderBy('id', 'desc')->get();
        }else {
            $Customers = Customers::where('status',9)->orderBy('id', 'desc')->get();
            $codename = null;
            $area_id = null;
            $leader_id = null;
            $visitor_id = null;
            $status = null;
        }



        $customersWithPurchaseCount = Pishfactor::where('organization_id', $user->organization_id)
            ->distinct('customer_id')
            ->count('customer_id');

        return view('customers.index', compact(
            'Customers',
            'customersWithPurchaseCount',
            'Cities',
            'Leaders',
            'Visitors',
            'Regions',
            'codename',
            'area_id',
            'leader_id',
            'visitor_id',
            'status',
        ));
    }

    public function store(Request $request)
    {
        $user = \Auth::user();




        foreach ($user->roles as $role) {
            $storesUser = DB::table('role_store')->where('role_id', $role->id)->pluck('store_id');
            if($role->title == 'visitor') {
                $isVisitor = true;
            }else {
                $isVisitor = false;
            }
        }
        if($isVisitor) {
            $request['leader_id'] = \Auth::user()->leader_id;
        }else {
            $request['leader_id'] = \Auth::user()->id;
        }


        $request['created_by'] = \Auth::user()->id;
        $Customer = Customers::create($request->all());
        $user = \Auth::user();
        if($request->customer_code == '') {
            $rand = rand(1000000000, 9999999999);
            $Selecte_rand = Customers::where('customer_code', $rand)->count();
            if($Selecte_rand > 0) {
                $rand = rand(1000000000, 9999999999);
                $Selecte_rand = Customers::where('customer_code', $rand)->count();
                if($Selecte_rand > 0) {
                    $rand = rand(1000000000, 9999999999);
                    $Selecte_rand = Customers::where('customer_code', $rand)->count();
                }
            }
        }


        $Customer->region_id = $request->region_id;
        $Cur_Region = Region::find($request->region_id);
        //$Customer->city_id = $Cur_Region->city_id;
        $Customer->customer_code = $request->customer_code != '' ? $request->customer_code : $rand;
        $Customer->organization_id = $Cur_Region->organization_id;
        $Customer->save();

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => 'یک مشتری ایجاد شد' . '-' . $Customer->name
        ]);

        Alert::success('تشکر', 'مشتری با موفقیت ایجاد شد');
        return back();
    }

    public function edit(Customers $customer)
    {
        $user = \Auth::user();


        $isManager = false;
        $isVisitor = false;
        foreach ($user->roles as $role) {
            if($role->title == 'visitor') {
                $isVisitor = true;
            }else {
                $isVisitor = false;
            }
            if($role->title == 'expert') {
                $isManager = true;
            }
        }
        if($user->isAdmin == 1) {
            $Regions = Region::forOrganizations($user)->get();
            $Areas = null;
        }elseif($isManager) {
            $Regions = Region::forOrganizations($user)->get();
            $Areas = null;
        }else{
            $Regions = Region::where('leader_id',$user->id)->get();
            $Areas = null;
        }

        if($isVisitor) {
            $regionIds = Tasks::where('user_id', auth()->id())
                ->where('status', 1)
                ->whereHas('area.region') // شرط اینکه ناحیه و ریجن وجود داشته باشند
                ->with('area.region')     // برای جلوگیری از N+1
                ->get()
                ->pluck('area.region_id') // استخراج region_id از رابطه‌ها
                ->unique()                // حذف شناسه‌های تکراری
                ->values();               // مرتب‌سازی ایندکس‌ها
            $MyTasks = Tasks::where('user_id', auth()->user()->id)->where('status',1)->get();
            $areaIds = Tasks::where('user_id', auth()->user()->id)->where('status',1)->pluck('area_id')->unique();
            $Regions = Region::whereIn('id',$regionIds)->get();
            $Areas = Area::whereIn('id',$areaIds)->get();
        }else {
            $MyTasks = null;
            $Areas = null;
        }
        $Cur_Area = Area::find($customer->area);
        $Cur_Region = Region::find($Cur_Area->region_id);
        $areaIds = Tasks::where('user_id', auth()->user()->id)->where('status',1)->pluck('area_id')->unique();
        $This_areas = Area::whereIn('id',$areaIds)->where('region_id',$Cur_Region->id)->get();

        session()->put('backlink', asset("/customers/$customer->id"));
        return view('customers.edit', compact('Regions', 'customer','Cur_Region','This_areas','Areas'));
    }

    public function update(Request $request, Customers $customer)
    {

        // dd($request->all());


        $customer->update([
            'name' => $request->name,
            'national_id' => $request->national_id,
            'economic_number' => $request->economic_number,
            'customer_code' => $request->customer_code,
            'phone' => $request->phone,
            'mobile' => $request->mobile,
            'tablo' => $request->tablo,
            'senf' => $request->senf,
            'channel' => $request->channel,
            'area' => $request->area,
            'region_id' => intval($request->region_id),
            'mapcode' => $request->mapcode,
            'address' => $request->address,
            'store_address' => $request->store_address,
            'shop_lat' => $request->shop_lat,
            'shop_lng' => $request->shop_lng,
            'store_lat' => $request->store_lat,
            'store_lng' => $request->store_lng,
            'updated_at' => now()
        ]);


        //Stores
        $user = \Auth::user();
        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'update',
            'description' => 'مشتری ویرایش شد' . '-' . $customer->name
        ]);

        Alert::success('تشکر', 'مشتری با موفقیت ویرایش شد');
        return back();
    }

    public function update_customer_info_by_visitor(Request $request, Customers $Customer)
    {

        $Customer->update([
            'name' => $request->name,
            'national_id' => $request->national_id,
            'economic_number' => $request->economic_number,
            'phone' => $request->phone,
            'mobile' => $request->mobile,
            'tablo' => $request->tablo,
            'senf' => $request->senf,
            'channel' => $request->channel,
            'address' => $request->address,
            'store_address' => $request->store_address,
            'updated_at' => now()
        ]);
        //Stores
        $user = \Auth::user();
        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'update',
            'description' => 'مشتری ویرایش شد' . '-' . $Customer->name
        ]);

        Alert::success('تشکر', 'مشتری با موفقیت ویرایش شد');
        return back();
    }

    public function createdByMe()
    {

        $user = \Auth::user();
        $Customers = Customers::where('created_by',$user->id)->get();
        // تعداد مشتریانی که خرید کرده‌اند
        $customersWithPurchaseCount = Pishfactor::distinct('customer_id')->count('customer_id');


        $codename = null;
        $area_id = null;
        $leader_id = null;
        $visitor_id = null;
        $status = null;


        return view('customers.index', compact('Customers','customersWithPurchaseCount','codename','area_id','leader_id','visitor_id'));

    }

    public function notify(Product $product)
    {
        $product->update([
            'isNotify' => 0
        ]);
        return back();
    }

    public function getCategory($id)
    {
        $childCategory_id = Category::where('parent_id', $id)
            ->where('isActive', 1)->get();
        return response()->json($childCategory_id);
    }

    public function getprs($id)
    {

        $Category = Category::find($id);

        $name = str_replace(" ", "_", $Category->title);

        $url = "http://daramino.localhost:8000/PRSApi/$name/";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $json = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($json);


        return response()->json($data->data);
    }

    public function update_customer_loc(Customers $Customer, Request $request) {

        if($request->shop_lat != '' || $request->shop_lat != null || !empty($request->shop_lat)) {
            $Customer->shop_lat = $request->shop_lat;
        }
        if($request->shop_lng != '' || $request->shop_lng != null || !empty($request->shop_lng)) {
            $Customer->shop_lng = $request->shop_lng;
        }

        if($request->sotre_lat != '' || $request->sotre_lat != null || !empty($request->sotree_lat)) {
            $Customer->store_lat = $request->sotre_lat;
        }
        if($request->sotre_lng != '' || $request->sotre_lng != null || !empty($request->sotre_lng)) {
            $Customer->store_llng = $request->sotre_lng;
        }
        $Customer->update();

        $user = \Auth::user();
        $username = $user->name;
        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'section' => 'customer',
            'section_id' => $Customer->id,
            'action' => 'update',
            'description' => "موقعیت مکانی مشتری توسط $username ویرایش شد شد" . '-' . $Customer->name
        ]);

        Alert::success('تشکر', 'موقعیت مشتری با موفقیت به روزرسانی شد');
        return back();


    }

    public function getStore($id)
    {
        $store_id = Store::where('organization_id', $id)
            ->where('isActive', 1)->get();
        return response()->json($store_id);
    }

    public function CustomerOrders($customer_id)
    {

        $user = \Auth::user();
        $Customer = Customers::find($customer_id);
        $isVisitor = false;
        $isManager = false;
        $isLeader = false;
        $PishFactors = Pishfactor::where('customer_id', $customer_id)->get();
        $Cities = City::forOrganizations($user)->get();

        return view('invoices.PishFactors', compact('PishFactors','Cities','isManager','isLeader','isVisitor'));

    }



    public function destroy($id)
    {

        $user = \Auth::user();
        $Customer = Customers::findOrFail($id);
        $Customer->delete();

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'delete',
            'description' => "مشتری $Customer->name توسط حساب $user->name حذف شد. "
        ]);

        Alert::success('تشکر', 'مشتری با موفقیت حذف شد');
        return back();
    }
}
