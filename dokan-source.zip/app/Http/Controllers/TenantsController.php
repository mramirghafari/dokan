<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Tenants;
use App\Models\Role;
use App\Models\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class TenantsController extends Controller
{
    public function __construct()
    {
        $this->middleware('can:tenants,user')->only(['index','store','edit','update']);
    }


        public function index()
    {
        $user = \Auth::user();
        $roles = Role::all();
        if ($user->isAdmin == 1) {

            $Tenants = Tenants::all();
        }
        return view('tenants.index',compact('Tenants'));
    }

    public function store(Request $request)
    {
        $Tenant = Tenants::create($request->all());
        $user = \Auth::user();
        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => 'پنل ایجاد شد' . '-' . $Tenant->name
        ]);

        Alert::success('تشکر', 'پنل با موفقیت ایجاد شد');
        return back();
    }

    public function edit($id) {
        $Tenant = Tenants::find($id);
        return view('tenants.edit',compact('Tenant'));
    }

    public function update(Request $request, Tenants $Tenant)
    {
        $Tenant->update([
            'name' => $request->name,
            'unit_order' => $request->unit_order,
            'sub_unit' => $request->sub_unit,
            'currency_type' => $request->currency_type,
            'tozihat' => $request->tozihat,
            'status' => $request->status,
        ]);
        $user = \Auth::user();
        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'update',
            'description' => 'پنل ویرایش شد' . '-' . $Tenant->name
        ]);

        Alert::success('تشکر', 'شعبه با موفقیت ویرایش شد');
        return redirect()->back();
    }




    public function destroy($id)
    {

        $user = \Auth::user();
        $Tenants = Tenants::findOrFail($id);
        $Tenants->delete();

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'delete',
            'description' => ' پنل توسط '.$user->name.' حذف شد' . '-' . $Tenants->title
        ]);


        return back();
    }

}
