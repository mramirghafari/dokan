<?php

namespace App\Http\Controllers;

use App\Models\Log;
use App\Models\Organization;
use App\Models\Role;
use Illuminate\Http\Request;
use App\Models\Store;
use App\Models\Tenants;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class StoreController extends Controller
{
    public function __construct()
    {
        $this->middleware('can:stores,user')->only(['index', 'store', 'edit', 'update']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $roles = Role::all();

        $user = \Auth::user();
        if ($user->isGod == 1) {
            $organizations = Organization::all();
            $stores = Store::all();
            $Products = Product::where('isActive', 1)->get();
        } else {
            $organizations = Organization::forOrganizations($user, 'id')->get();
            $stores = Store::forOrganizations($user)->get();
            $Products = Product::where('isActive', 1)->forOrganizations($user)->get();
        }


        return view('stores.index', compact('stores', 'roles', 'organizations', 'Products'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // dd($request->all());
        $user = \Auth::user();
        $organizationId = $this->resolveAllowedOrganizationId($request->organization_id, $user);
        $tenantId = $this->resolveTenantId($organizationId, $user);

        $request['organization_id'] = $organizationId;
        $request['tenants_id'] = $tenantId;
        $store = Store::create($request->all());
        $store->roles()->sync($request->roles);

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => 'انبار ایجاد شد' . '-' . $store->title
        ]);

        Alert::success('تشکر', 'انبار با موفقیت ایجاد شد');
        return back();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Store $store)
    {
        $roles = Role::all();

        $user = \Auth::user();
        if ($user->isGod == 1) {
            $organizations = Organization::all();
            $stores = Store::all();
            $Products = Product::where('isActive', 1)->get();
        } else {
            $organizations = Organization::forOrganizations($user, 'id')->get();
            $stores = Store::forOrganizations($user)->get();
            $Products = Product::where('isActive', 1)->forOrganizations($user)->get();
        }


        return view('stores.edit', compact('stores', 'store', 'roles', 'organizations', 'Products'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Store $store)
    {

        // dd($request->all());
        $user = \Auth::user();
        $roles = Role::all();

        $organizationId = $this->resolveAllowedOrganizationId($request->organization_id, $user);
        $tenantId = $this->resolveTenantId($organizationId, $user);
        $request->isActive == "on" ? $request->isActive = 1 : $request->isActive = 0;
        $store->update([
            'title' => $request->title,
            'description' => $request->description,
            'code' => $request->code,
            'organization_id' => $organizationId,
            'pr_ids' => $request->pr_ids,
            'lat' => $request->lat,
            'lang' => $request->lang,
            'isActive' => $request->isActive
        ]);
        $store->update([
            'tenants_id' => $tenantId,
        ]);
        $store->roles()->sync($request->roles);

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'update',
            'description' => 'انبار ویرایش شد' . '-' . $store->title
        ]);

        $user = \Auth::user();
        if ($user->isGod == 1) {
            $organizations = Organization::where('isActive', 1)->get();
            $stores = Store::where('isActive', 1)->get();
        } else {
            $organizations = Organization::forOrganizations($user, 'id')->where('isActive', 1)->get();
            $stores = Store::forOrganizations($user)->where('isActive', 1)->get();
        }

        Alert::success('تشکر', 'رکورد با موفقیت ویرایش شد');
        return redirect()->route('stores.edit', compact('store', 'stores', 'roles', 'organizations'));
    }

    private function resolveAllowedOrganizationId($requestedOrganizationId, $user)
    {
        if ($user->isGod == 1) {
            return $requestedOrganizationId;
        }

        return $user->organization_id;
    }

    private function resolveTenantId($organizationId, $user)
    {
        $organization = $organizationId ? Organization::find($organizationId) : null;

        return $organization ? $organization->tenants_id : $user->tenants_id;
    }
}
