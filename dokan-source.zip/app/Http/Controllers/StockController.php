<?php

namespace App\Http\Controllers;

use App\Http\Requests\StockRequest;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;
use App\Models\Stock;
use App\Models\Pishfactor;
use App\Models\PishFactorItems;
use App\Models\Brand;
use App\Models\Depot;
use App\Models\Employee;
use App\Models\History;
use App\Models\Log;
use App\Models\Organization;
use App\Models\Store;
use Auth;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Database\Eloquent\Builder;
use App\Models\MaterialStore;
use App\Models\Material;

class StockController extends Controller
{
    public function __construct()
    {
        $this->middleware('can:stocks,user')->only(['index', 'create', 'store', 'edit', 'update', 'destroy', 'trashGet', 'trashPost', 'restore']);
    }

    public function index()
    {
        $categories = Category::where('isActive', 1)->where('parent_id', Null)->get();
        $brands = Brand::where('isActive', 1)->get();
        $parents = Category::where('isActive', 1)->where('parent_id', '!=', Null)->get();

        //Stores
        $user = \Auth::user();

        if ($user->isGod == 1) {
            $organizations = Organization::where('isActive', 1)->get();
            $stocks = Stock::where('isActive', 1)->get();
            $stores = Store::where('isActive', 1)->get();
            $Products = Product::where('isActive', 1)->get();
        }elseif ($user->isAdmin == 1) {
            $organizations = Organization::where('isActive', 1)->get();
            $stocks = Stock::where('isActive', 1)->get();
            $stores = Store::where('isActive', 1)->get();
            $Products = Product::where('isActive', 1)->whereIn('organization_id', is_array(json_decode($user->organization_id)) ? json_decode($user->organization_id) : [intval($user->organization_id)])->get();
        } else {
            $organizations = Organization::where('id', $user->organization_id)->where('isActive', 1)->get();
            foreach ($user->roles as $role) {
                $storesUser = DB::table('role_store')->where('role_id', $role->id)->pluck('store_id');
            }
            $stocks = Stock::whereIn('store_id', $storesUser)->where('isActive', 1)->get();

            $stores = Store::whereIn('id', $storesUser)->where('isActive', 1)->get();
            $Products = Product::where('isActive', 1)->whereIn('organization_id', is_array(json_decode($user->organization_id)) ? json_decode($user->organization_id) : [intval($user->organization_id)])->get();
        }

        return view('stocks.index', compact('Products','stocks', 'categories', 'brands', 'parents','stores'));
    }

    public function create()
    {
        $categories = Category::where('isActive', 1)->where('parent_id', Null)->get();
        $brands = Brand::where('isActive', 1)->get();
        $parents = Category::where('isActive', 1)->where('parent_id', '!=', Null)->get();

        //Stores
        $user = \Auth::user();
        if ($user->isAdmin == 1) {
            $organizations = Organization::where('isActive', 1)->get();
            $stores = Store::where('isActive', 1)->get();
            $employees = Employee::where('isActive', 1)->get();
        } else {
            $organizations = Organization::where('id', $user->organization_id)->where('isActive', 1)->get();
            foreach ($user->roles as $role) {
                $storesUser = DB::table('role_store')->where('role_id', $role->id)->pluck('store_id');
            }
            $employees = Employee::where('isActive', 1)->where('organization_id', $user->organization_id)->get();

            $stores = Store::whereIn('id', $storesUser)->where('isActive', 1)->get();
        }

        return view('stocks.create', compact('employees', 'categories', 'stores', 'brands', 'parents', 'organizations'));
    }

    public function store(Request $request)
    {

        //dd($request->all());
        $request['user_id'] = \Auth::user()->id;
        $Product = Product::find($request->pr_id);
        $Store = Store::find($request->store_id);
        $request['organization_id'] = $Store->organization_id;

        $stock = Stock::create($request->all());
        $user = \Auth::user();

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => 'ثبت تولید و موجودی جدید محصول ایجاد شد' . '-' . $Product->title
        ]);

        History::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'entity',
            'store' => $stock->store->title,
            'description' => " برای محصول " . $Product->title . " تعداد " . $stock->entity . " عدد ثبت شد"
        ]);

        Alert::success('تشکر', 'رکورد با موفقیت ایجاد شد');
        return back();
    }

    public function edit(Stock $stock)
    {
        $categories = Category::where('isActive', 1)->where('parent_id', Null)->get();
        $brands = Brand::where('isActive', 1)->get();
        $parents = Category::where('isActive', 1)->where('parent_id', '!=', Null)->get();

        //Stores
        $user = \Auth::user();
        if ($user->isAdmin == 1) {
            $organizations = Organization::where('isActive', 1)->get();
            $stores = Store::where('isActive', 1)->get();
            $employees = Employee::where('isActive', 1)->get();
        } else {
            $organizations = Organization::where('id', $user->organization_id)->where('isActive', 1)->get();
            foreach ($user->roles as $role) {
                $storesUser = DB::table('role_store')->where('role_id', $role->id)->pluck('store_id');
            }
            $stores = Store::whereIn('id', $storesUser)->where('isActive', 1)->get();
            $employees = Employee::where('isActive', 1)->where('organization_id', $user->organization_id)->get();
        }

        return view('stocks.edit', compact('employees', 'stock', 'categories', 'stores', 'brands', 'parents', 'organizations'));
    }

    public function update(StockRequest $request, Stock $stock)
    {


        $request->isActive == "on" ? $request->isActive = 1 : $request->isActive = 0;
        $request['inputDate'] = $this->to_english_numbers($request['inputDate']);
        $number = $stock->entity;

        $stock->update([
            'title' => $request->title,
            'description' => $request->description,
            'entity' => $request->entity,
            'brand_id' => $request->brand_id,
            'parentCategory_id' => $request->parentCategory_id,
            'chaildCategory_id' => isset($request->chaildCategory_id) ? $request->chaildCategory_id : $stock->chaildCategory_id,
            'isActive' => $request->isActive,
            'organization_id' => $request->organization_id,
            'store_id' => isset($request->store_id) ? $request->store_id : $stock->store_id,
            'inputDate' => $request->inputDate,
            'employee_id' => isset($request->employee_id) ? $request->employee_id : $stock->employee_id,
        ]);

        $user = \Auth::user();

        Log::create([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_id' => $user->id,
            'action' => 'create',
            'description' => 'کالا ویرایش شد' . '-' . $stock->title
        ]);

        if ($number != $stock->entity) {
            History::create([
                'ip' => $_SERVER['REMOTE_ADDR'],
                'user_id' => $user->id,
                'action' => 'editEntity',
                'store' => $stock->store->title,
                'description' => " برای کالای دست دوم " . $stock->title . " از تعداد " . $number . " به تعداد " . $stock->entity . " تغییر یافت"
            ]);
        }

        Alert::success('تشکر', 'رکورد با موفقیت ویرایش شد');
        return back();
    }

    public function need_entity ()
    {
        $user = \Auth::user();

        if ($user->isGod == 1) {
            $PishFactors = Pishfactor::where('status', 1)->get();
        }else {
            $PishFactors = Pishfactor::where('status', 1)->where('organization_id', $user->organization_id)->get();
        }


        // استخراج محصولات و محاسبه مجموع tedad و pack
        $Items = $PishFactors->flatMap(function ($pishfactor) {
            return $pishfactor->items->map(function ($item) {
                return [
                    'product_id' => $item->pr_id, // شناسه محصول
                    'tedad' => $item->tedad,     // تعداد
                    'pack' => $item->pack        // تعداد بسته‌بندی
                ];
            });
        })->groupBy('product_id')->map(function ($group) {
            return [
                'total_tedad' => $group->sum('tedad'),
                'total_pack' => $group->sum('pack')
            ];
        });

        return view('stocks.need-stock', compact('Items'));

    }

    public function entrance()
    {
        $user = \Auth::user();

        if ($user->isGod == 1) {
            $Stores = Store::all();
        }else {
            $Stores = Store::forOrganizations($user)->get();
        }


        return view('stocks.entrance', compact('Stores'));

    }

    public function entrance_transfer()
    {
        $user = \Auth::user();

        if ($user->isGod == 1) {
            $Stores = Store::all();
        }else {
            $Stores = Store::forOrganizations($user)->get();
        }


        return view('stocks.entrance_transfer', compact('Stores'));

    }

    public function storeProducts(Store $store) {

        $Products =  Product::whereJsonContains('store_id', "$store->id")
            ->withSum(['depots as total_entity' => function (Builder $query) {
                $query->select(DB::raw("COALESCE(SUM(entity), 0)"));
            }], 'entity')
            ->withSum(['depots as total_entity_sub_unit' => function (Builder $query) {
                $query->select(DB::raw("COALESCE(SUM(entity_sub_unit), 0)"));
            }], 'entity_sub_unit')
            ->withSum(['pishfactorItems as total_pack' => function (Builder $query) {
                $query->select(DB::raw("COALESCE(SUM(pack), 0)"));
            }], 'pack')
            ->withSum(['pishfactorItems as total_tedad' => function (Builder $query) {
                $query->select(DB::raw("COALESCE(SUM(tedad), 0)"));
            }], 'tedad')
            ->get();
        return view('stocks.store_products', compact('store','Products'));

    }

    public function storeProductsForTransfer(Store $store) {

        $Products = Product::whereJsonContains('store_id', "$store->id")->get();
        return view('stocks.store_products_for_transfer', compact('store','Products'));

    }

    public function storeProductCartex(Store $store, Product $product)
    {
        // ۱) depots رو با receipt بگیر
        $Depots = Depot::with(['receipt' => function ($q) {
            $q->select('*');
        }])
            ->where('pr_id', $product->id)
            ->where('store_id', $store->id)
            ->get();


        // ۲) فروش روزانه فقط برای پیش‌فاکتورهای با status = 1 یا 4
        $salesByDay = DB::table('pish_factor_items')
            ->join('pishfactors', 'pish_factor_items.pishfactor_id', '=', 'pishfactors.id')
            ->select(
                DB::raw('DATE(pishfactors.created_at) as date'),
                DB::raw('SUM(pish_factor_items.pack) as total_pack'),
                DB::raw('SUM(pish_factor_items.tedad) as total_tedad')
            )
            ->where('pish_factor_items.pr_id', $product->id)
            ->whereIn('pishfactors.status', [1, 4])
            ->groupBy(DB::raw('DATE(pishfactors.created_at)'))
            ->get()
            ->keyBy('date');

        // ۳) شروع ساخت تایم‌لاین
        $timeline = collect();

        // اضافه کردن رکوردهای فروش
        foreach ($salesByDay as $date => $sale) {
            $timeline->push([
                'type'       => 'sale',
                'date'       => $date,
                // محاسبه کل خروجی به واحد اصلی
                'total_main' => ($sale->total_pack * ($product->pack_items ?? 1)) + $sale->total_tedad,
                'pack'       => $sale->total_pack,
                'tedad'      => $sale->total_tedad,
                'details'    => null,
            ]);
        }

        // اضافه کردن رکوردهای Depot همراه با Receipt
        foreach ($Depots as $depot) {
            $timeline->push([
                'type'       => 'depot',
                'date'       => $depot->created_at->format('Y-m-d'),
                'tedad'      => $depot->entity,
                'receipt'    => $depot->receipt,
            ]);
        }

        // ۴) سورت نهایی بر اساس تاریخ (قدیمی → جدید)
        $timeline = $timeline->sortBy('date')->values();

        return view('stocks.store_product_depot', compact('store', 'product', 'timeline'));
    }



    public function PrCartexList() {

        $user = \Auth::user();
        if($user->store_id != null) {
            $stores = Store::whereIn('id', $user->store_id)->pluck('id');
        }else {
            $stores = Store::pluck('id')->toArray();
        }


        $query = Product::query();

        foreach ($stores as $id) {
            $query->orWhereJsonContains('store_id', "$id");
        }

        $Products = $query->get();


        return view('stocks.ProductListCartex', compact('Products'));

    }

    public function PrCartex(Product $product){

        // فرض: اینا کوئری‌های اصلی شما هستن
        $Depots = Depot::where('pr_id', $product->id)->get();

        $salesByDay = DB::table('pish_factor_items')
            ->join('pishfactors', 'pish_factor_items.pishfactor_id', '=', 'pishfactors.id')
            ->select(
                DB::raw('DATE(pishfactors.created_at) as date'),
                DB::raw('SUM(pish_factor_items.pack) as total_pack'),
                DB::raw('SUM(pish_factor_items.tedad) as total_tedad')
            )
            ->where('pish_factor_items.pr_id', $product->id)
            ->groupBy(DB::raw('DATE(pishfactors.created_at)'))
            ->get()
            ->keyBy('date');

        $timeline = collect();

// اضافه کردن رکوردهای فروش روزانه
        foreach ($salesByDay as $date => $sale) {
            $timeline->push([
                'type' => 'sale',
                'date' => $date,
                'pack' => $sale->total_pack,
                'tedad' => $sale->total_tedad,
                'details' => null,
            ]);
        }

// اضافه کردن رکوردهای Depot (ورودی‌ها)
        foreach ($Depots as $depot) {
            $timeline->push([
                'type' => 'depot',
                'date' => $depot->created_at->format('Y-m-d'),
                'pack' => $depot->entity_sub_unit,
                'tedad' => $depot->entity,
                'details' => $depot, // می‌تونی اطلاعات کامل depot رو اینجا نگه داری
            ]);
        }

// سورت نهایی بر اساس تاریخ از آخر به اول
        $timeline = $timeline->sortByDesc('date')->values();

        return view('stocks.productCartex', compact('timeline','product'));

    }

    public function store_cartex()
    {

        $user = \Auth::user();
        if($user->store_id != null) {
            $stores = Store::whereIn('id', $user->store_id)->get();
        }else {
            $stores = Store::all();
        }

        return view('stocks.storeCartex', compact('stores'));

    }

    public function import_stock()
    {
        $user = \Auth::user();

        if ($user->isGod == 1) {
            $Stores = Store::all();
        }else {
            $Stores = Store::forOrganizations($user)->get();
        }


        return view('stocks.importPage', compact('Stores'));
    }

    public function StockTransfer()
    {
        $user = \Auth::user();

        if ($user->isGod == 1) {
            $Stores = Store::all();
        }else {
            $Stores = Store::forOrganizations($user)->get();
        }


        return view('stocks.storeTransfer', compact('Stores'));
    }



    public function ProductionByExtraction() {
        $user = \Auth::user();
        if($user->isGod == 1) {
            $Stores = Store::all();
            $Materials = Product::where('isMaterial',1)->where('isActive',1)->get();
            $Products = Product::where('isMaterial',0)->where('isActive',1)->get();
        }else {
            $Stores = Store::forOrganizations($user)->get();
            $Materials = Product::forOrganizations($user)->where('isMaterial',1)->where('isActive',1)->get();
            $Products = Product::forOrganizations($user)->where('isMaterial',0)->where('isActive',1)->get();
        }

        return view('stocks.ProductionByExtraction', compact('Stores','Materials','Products'));
    }

    public function ProductionByExtractionProcess(Request $request)
    {
        //dd($request->all());
        $material_id = $request->get('material_id');
        $Material = Product::find($material_id);
        $entity = $request->get('entity');
        $prs = $request->get('prs');
        $estehsal = $request->get('estehsal');
        $taamdar = $request->get('taamdar');
        $Store = json_decode($Material->store_id);
        dd($Store[0]);

        $Receipt = new Receipt();
    }

    public function ProductStock(Product $product)
    {
        echo $product->current_stock;
    }



    public function getEmployee($id)
    {
        $employee_id = Employee::where('organization_id', $id)
            ->where('isActive', 1)->get();
        return response()->json($employee_id);
    }

    public function getCategory($id)
    {
        $childCategory_id = Category::where('parent_id', $id)
            ->where('isActive', 1)->get();
        return response()->json($childCategory_id);
    }

    public function getStore($id)
    {
        $store_id = Store::where('organization_id', $id)
            ->where('isActive', 1)->get();
        return response()->json($store_id);
    }

    public function destroy($id)
    {
        $stock = Stock::findOrFail($id);
        $stock->delete();
        return back();
    }

    function to_english_numbers(String $string): String
    {
        $persinaDigits1 = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $persinaDigits2 = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١', '٠'];
        $allPersianDigits = array_merge($persinaDigits1, $persinaDigits2);
        $replaces = [...range(0, 9), ...range(0, 9)];

        return str_replace($allPersianDigits, $replaces, $string);
    }
}
