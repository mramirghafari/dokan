<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use App\Models\User;

class LoginController extends Controller
{
    use AuthenticatesUsers;

    /**
     * مسیر بعد از لاگین موفق
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * ایجاد کنترلر
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * بررسی اعتبارسنجی و فعال‌بودن کاربر قبل از لاگین
     */
    protected function attemptLogin(Request $request)
    {
        // پیدا کردن کاربر بر اساس ایمیل
        $user = User::where('email', $request->email)->first();

        // اگر کاربر وجود دارد ولی غیرفعال است → خطا بده
        if ($user && $user->isActive === 0) {
            throw ValidationException::withMessages([
                'email' => ['کاربری توسط مدیریت غیرفعال شده است.'],
            ]);
        }

        // در غیر این صورت لاگین انجام بده
        return $this->guard()->attempt(
            $this->credentials($request),
            $request->filled('remember')
        );
    }

    /**
     * پارامترهای اعتبارسنجی کاربر
     */
    protected function credentials(Request $request)
    {
        return [
            'email' => $request->get('email'),
            'password' => $request->get('password'),
        ];
    }
}
