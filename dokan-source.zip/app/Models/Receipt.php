<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\HasOrganizationFilter;


class Receipt extends Model
{
    use HasFactory,SoftDeletes,HasOrganizationFilter;

    protected $fillable = ['user_id','type','store_id','to_store_id','number','date_fa','date_en','sender','moeen','driver','tozihat','updated_at'];

    public function user()
    {
        return $this->belongsTo(User::class,'user_id');
    }

    public function store()
    {
        return $this->belongsTo(Store::class,'store_id');
    }
    public function depots()
    {
        return $this->hasMany(Depot::class);
    }

}

