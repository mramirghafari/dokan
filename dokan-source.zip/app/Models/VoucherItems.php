<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VoucherItems extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['voucher_id','amount','account_id','method','payment_terminal_id','issuing_bank','due_date','cheque_photo'];

    public function voucher()
    {
        return $this->belongsTo(Voucher::class, 'voucher_id');
    }

    public function account()
    {
        return $this->belongsTo(Accounts::class, 'account_id');
    }

}
