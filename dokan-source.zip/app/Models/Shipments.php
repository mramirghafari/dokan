<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\HasOrganizationFilter;

class Shipments extends Model
{
    use HasFactory, SoftDeletes, HasOrganizationFilter;

    protected $fillable = [
        'organization_id',
        'owner_id',
        'driver_id',
        'number',
        'tozihat',
        'date_fa',
        'date_en',
        'hours',
        'mabda',
        'origin_lat',
        'origin_lang',
        'status'
    ];

    /**
     * 📦 راننده مرتبط با شیپمنت
     */
    public function driver()
    {
        return $this->belongsTo(User::class, 'driver_id', 'id');
    }

    /**
     * 🚚 حمل‌ونقل‌های مربوط به این شیپمنت
     */
    public function routes()
    {
        return $this->hasMany(\App\Models\ShipmentRoute::class, 'shipment_id', 'id');
    }
}
