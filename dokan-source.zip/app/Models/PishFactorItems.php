<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PishFactorItems extends Model
{
    use HasFactory;
    protected $fillable = ['pishfactor_id','pr_id','pack','tedad','price','discount'];

    public $timestamps = false;

    public function product()
    {
        return $this->belongsTo(Product::class, 'pr_id', 'id');
    }
    public function pishfactor()
    {
        return $this->belongsTo(Pishfactor::class, 'pishfactor_id');
    }

}
