<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TargetProducts extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['target_id','pr_id','order_count','order_price','status'];


    public function target(){
        return $this->belongsTo(Targets::class, 'target_id');
    }

    public function products(){
        return $this->belongsTo(Product::class, 'pr_id');
    }
}
