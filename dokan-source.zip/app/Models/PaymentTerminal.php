<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\HasOrganizationFilter;

class PaymentTerminal extends Model
{

    use HasFactory, SoftDeletes,HasOrganizationFilter;
    protected $fillable = [
        'account_id',
        'terminal_type',      // pos, gateway, wallet ...
        'provider_name',      // Mellat, ZarinPal ...
        'terminal_number',    // شماره خاص پایانه یا merchantId
        'title',              // عنوان نمایشی
        'description',              // توضیحات
        'type',              // نوع
        'is_active',
        'tenants_id',
        'organization_id',
        'created_by',
    ];

    public function account()
    {
        return $this->belongsTo(Accounts::class);
    }
}
