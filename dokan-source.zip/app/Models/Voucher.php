<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Voucher extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['factor_id','account_id','voucher_type','voucher_number','voucher_date_fa','voucher_date_en','amount','method','description'];

    public function items()
    {
        return $this->hasMany(VoucherItems::class, 'voucher_id');
    }

    public function account()
    {
        return $this->belongsTo(Accounts::class, 'account_id');
    }

    public function invoice()
    {
        return $this->belongsTo(Pishfactor::class, 'factor_id');
    }
}
