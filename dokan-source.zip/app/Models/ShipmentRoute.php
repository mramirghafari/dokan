<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShipmentRoute extends Model
{
    protected $fillable = [
        'shipment_id',
        'factor_id',
        'route_index',
        'origin_lat',
        'origin_lng',
        'destination_lat',
        'destination_lng',
        'distance_meters',
        'duration_minutes',
        'path_json',
        'status',
        'extra_info',
    ];

    protected $casts = [
        'path_json' => 'array',
        'extra_info' => 'array',
    ];

    /**
     * 🚚 ارتباط با سفر مربوطه
     */
    public function shipment()
    {
        return $this->belongsTo(Shipments::class, 'shipment_id', 'id');
    }

    /**
     * 📦 ارتباط با پیش‌فاکتور مربوطه
     */
    public function pishfactor()
    {
        return $this->belongsTo(\App\Models\Pishfactor::class, 'factor_id', 'id');
    }
}
