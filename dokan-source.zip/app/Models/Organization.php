<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\HasOrganizationFilter;

class Organization extends Model
{
    use HasFactory,SoftDeletes,HasOrganizationFilter;

    protected $fillable = ['title','description','type','unit_order','sub_unit','pr_type','currency_type','unit_display','isActive','tenants_id'];

    public function users()
    {
        return $this->belongsToMany(User::class);
    }

    public function employees()
    {
        return $this->belongsToMany(Employee::class);
    }

    public function stores()
    {
        return $this->belongsToMany(Store::class);
    }

    public function unit()
    {
        return $this->belongsTo(Unit::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }


}
