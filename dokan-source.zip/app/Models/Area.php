<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Area extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['name','region_id','leader_id'];

    public function customers()
    {
        return $this->hasMany(Customers::class, 'area', 'id');
    }


    public function region()
    {
        return $this->belongsTo(Region::class, 'region_id', 'id');
    }

    public function customersCount()
    {
        return $this->customers()->count();
    }

    public function activeCustomers()
    {
        return $this->customers() // همه مشتری‌های این ناحیه
        ->get()
            ->filter(function ($customer) {
                return $customer->pishfactors()
                    ->whereIn('status', [1, 4]) // فاکتور فعال
                    ->exists(); // حداقل یک فاکتور فعال داشته باشد
            })
            ->values(); // مرتب کردن index‌ها در collection نهایی
    }

    public function activeCustomersCount()
    {
        return $this->customers() // مشتری‌های این مسیر
        ->whereHas('pishfactors') // فقط مشتریانی که فاکتور دارند
        ->distinct('customers.id')
            ->count('customers.id');
    }

    public function activeOrders()
    {
        return \App\Models\Pishfactor::query()
            ->whereIn('customer_id', function ($query) {
                $query->select('id')
                    ->from('customers')
                    ->where('area', $this->id);
            })
            ->whereIn('status', [1, 4]) // فقط فاکتورهای فعال
            ->get();
    }

    public function activeOrdersSum()
    {
        return $this->customers()
            ->join('pishfactors', 'customers.id', '=', 'pishfactors.customer_id')
            ->whereIn('pishfactors.status', [1, 4]) // فقط فاکتورهای فعال
            ->sum('pishfactors.fullPrice'); // جمع مبلغ فاکتورهای فعال
    }

    public function roles(){
        return $this->belongsToMany(Role::class);
    }
}
