<?php

namespace App\Models;

use App\Casts\changeDate;
use Illuminate\Database\Eloquent\Model;

class Notifs extends Model
{

    protected $table = 'notifs';
    protected $fillable = [
        'id', 'user_id', 'title', 'content', 'status'
    ];

    public function table()
    {
        return $this->belongsTo(\App\Tables::class);
    }
}
