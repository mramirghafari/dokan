<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Accounts extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['code','name','level','type','nature','account_number','card_number','iban','branch','currency_type','isActive','parent_id','organization_id','tenants_id','created_by'];

    public function vouchers()
    {
        return $this->hasMany(Voucher::class, 'account_id');
    }

    public function voucherItems()
    {
        return $this->hasMany(VoucherItems::class, 'account_id');
    }
}
