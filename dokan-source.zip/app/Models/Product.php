<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Builder; // کلاس درست
use App\Traits\HasOrganizationFilter;
use Illuminate\Support\Facades\DB;


class Product extends Model
{
    use HasFactory,SoftDeletes,HasOrganizationFilter;
    protected $fillable = ['title','display_name','orderLimit','category_id','entity','brand_id','isActive','user_id','description','organization_id','store_id','sku','parentCategory_id','childCategory_id','start_date','exp_date','pr_unit','pr_sub_unit','pr_weight','pr_weight_txt','pack_items','pr_weight','pr_weight_unit','pack_weight','pack_weight_unit','pack_weight_txt','price','discount','tax','fee_masraf','photo','attrs','item_sale_status','pack_sale_status','isFreez','isNotify','set_price','isMaterial','depot_id','updated_at'];

    public function parentCategory()
    {
        return $this->belongsTo(Category::class,'parentCategory_id');
    }

    public function childCategory()
    {
        return $this->belongsTo(Category::class,'childCategory_id');
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }

    public function organization()
    {
        return $this->belongsTo(Organization::class);
    }

    public function store()
    {
        return $this->belongsTo(Store::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function details()
    {
        return $this->belongsToMany(Detail::class);
    }

    public function depots()
    {
        return $this->hasMany(Depot::class, 'pr_id', 'id');
    }

    public function pishfactorItems()
    {
        return $this->hasMany(PishFactorItems::class, 'pr_id');
    }


    public function currentStock($storeId = null)
    {
        // 1- ورودی‌ها (Depot)
        $totalIn = Depot::where('pr_id', $this->id)
            ->when($storeId, function ($q) use ($storeId) {
                $q->where('store_id', $storeId);
            })
            ->sum('entity');

        // 2- خروجی‌ها (PishFactorItems با status = 1 یا 4)
        $soldItems = \App\Models\PishFactorItems::where('pr_id', $this->id)
            ->when($storeId, function ($q) use ($storeId) {
                $q->where('store_id', $storeId);
            })
            ->whereHas('pishfactor', function ($q) {
                $q->whereIn('status', [1, 4]);
            })
            ->get();

        // 3- محاسبه تعداد فروخته شده به واحد اصلی محصول
        $totalOut = $soldItems->reduce(function ($carry, $item) {
            $packCount = $item->pack ?? 0;
            $singleCount = $item->tedad ?? 0;
            $packSize = $this->pack_items ?? 1; // از مدل Product
            return intval($carry) + (intval($packCount) * intval($packSize)) + intval($singleCount);
        }, 0);

        // 4- موجودی فعلی
        return $totalIn - $totalOut;
    }

    public function getCreatedAtAttribute($created_at)
    {
        $v1 = new \Verta($created_at);
        $v1 = $v1->format('H:m:s - Y/m/d');
        return $v1;
    }

    public function getUpdatedAtAttribute($updated_at)
    {
        $v1 = new \Verta($updated_at);
        $v1 = $v1->format('H:m:s - Y/m/d');
        return $v1;
    }

    public function getFirstPeriodMain($storeId)
    {
        return $this->depots()
            ->where('store_id', $storeId)
            ->whereHas('receipt', function ($q) {
                $q->where('type', 5);
            })
            ->sum('entity');
    }

    public function getFirstPeriodSub($storeId)
    {
        $packItems = $this->pack_items ?: 1;

        return $this->depots()
                ->where('store_id', $storeId)
                ->whereHas('receipt', function ($q) {
                    $q->where('type', 5);
                })
                ->sum('entity') / $packItems;
    }

    public function getInputMain($storeId)
    {
        return $this->depots()
            ->where('store_id', $storeId)
            ->whereHas('receipt', function ($q) {
                $q->whereIn('type', [1, 2, 3, 4]);
            })
            ->sum('entity');
    }

    public function getInputSub($storeId)
    {
        $packItems = $this->pack_items ?: 1;

        return $this->depots()
                ->where('store_id', $storeId)
                ->whereHas('receipt', function ($q) {
                    $q->whereIn('type', [1, 2, 3, 4]);
                })
                ->sum('entity') / $packItems;
    }

    public function getOutputMain()
    {
        $packItems = $this->pack_items ?: 1;

        return $this->pishfactorItems()
            ->whereHas('pishfactor', function ($q) {
                $q->whereIn('status', [1, 4]);
            })
            ->get()
            ->reduce(function ($carry, $item) use ($packItems) {
                $packCount  = intval($item->pack) * $packItems;
                $singleCount = intval($item->tedad);
                return $carry + $packCount + $singleCount;
            }, 0);
    }

    public function getOutputSub()
    {
        $packItems = $this->pack_items ?: 1;
        $totalMain = $this->getOutputMain();

        return round($totalMain / $packItems, 2);
    }

    public function getCurrentStock($storeId)
    {
        return $this->getFirstPeriodMain($storeId)
            + $this->getInputMain($storeId)
            - $this->getOutputMain();
    }

    protected static function booted()
    {
        static::addGlobalScope('withCurrentStock', function (Builder $builder) {
            $builder
                ->select('products.*')

                // مجموع ورودی‌ها
                ->selectSub(function ($q) {
                    $q->from('depots')
                        ->selectRaw('COALESCE(SUM(entity),0)')
                        ->whereColumn('depots.pr_id', 'products.id');
                }, 'total_in')

                // مجموع خروجی‌ها
                ->selectSub(function ($q) {
                    $q->from('pish_factor_items')
                        ->join('pishfactors', 'pish_factor_items.pishfactor_id', '=', 'pishfactors.id')
                        ->whereColumn('pish_factor_items.pr_id', 'products.id')
                        ->whereIn('pishfactors.status', [1, 4])
                        ->selectRaw(
                            'COALESCE(SUM((pish_factor_items.pack * products.pack_items) + pish_factor_items.tedad),0)'
                        );
                }, 'total_out')

                // موجودی فعلی
                ->selectSub(function ($q) {
                    $q->from('depots as d')
                        ->selectRaw('
                            COALESCE(SUM(d.entity),0) -
                            COALESCE((
                                SELECT SUM((pfi.pack * products.pack_items) + pfi.tedad)
                                FROM pish_factor_items pfi
                                JOIN pishfactors pf ON pfi.pishfactor_id = pf.id
                                WHERE pfi.pr_id = products.id
                                AND pf.status IN (1,4)
                            ),0)
                        ')
                        ->whereColumn('d.pr_id', 'products.id');
                }, 'current_stock');
        });
    }

    public function scopeWithSalesReport(
        $query,
        $startDate = null,         // تاریخ ثبت شروع
        $endDate = null,           // تاریخ ثبت پایان
        $deliveryStart = null,     // تاریخ تحویل شروع
        $deliveryEnd = null        // تاریخ تحویل پایان
    ) {
        $totalInSQL = "(SELECT COALESCE(SUM(entity), 0)
                    FROM depots
                    WHERE depots.pr_id = products.id)";

        $totalOutSQL = "(SELECT COALESCE(SUM((pish_factor_items.pack * products.pack_items) + pish_factor_items.tedad), 0)
                     FROM pish_factor_items
                     JOIN pishfactors ON pish_factor_items.pishfactor_id = pishfactors.id
                     WHERE pish_factor_items.pr_id = products.id
                     AND pishfactors.status IN (1, 4))";

        $query->select('products.*')
            ->addSelect(DB::raw('COUNT(DISTINCT pfi.pishfactor_id) as invoice_count'))
            ->addSelect(DB::raw('SUM((pfi.pack * products.pack_items) + pfi.tedad) as total_qty'))
            ->addSelect(DB::raw("
            SUM(
                (
                    ((pfi.pack * products.pack_items) + pfi.tedad)
                    * pfi.price
                )
                * (1 - (COALESCE(pfi.discount,0) / 100))
                * (1 + (COALESCE(products.tax,0) / 100))
            ) as total_amount
        "))
            ->addSelect(DB::raw("$totalInSQL as total_in"))
            ->addSelect(DB::raw("$totalOutSQL as total_out"))
            ->addSelect(DB::raw("($totalInSQL - $totalOutSQL) as current_stock"))
            ->addSelect(DB::raw("(($totalInSQL - $totalOutSQL) * products.price) as stock_value"))
            ->leftJoin('pish_factor_items as pfi', 'products.id', '=', 'pfi.pr_id')
            ->leftJoin('pishfactors as pf', 'pfi.pishfactor_id', '=', 'pf.id')
            ->whereIn('pf.status', [1, 4])
            ->groupBy('products.id');

        // فیلتر تاریخ ثبت فاکتور
        if ($startDate && $endDate) {
            $query->whereBetween('pf.created_at', [$startDate, $endDate]);
        }

        // فیلتر تاریخ تحویل، اگر هر دو مقدار باشه
        if ($deliveryStart && $deliveryEnd) {
            $query->whereBetween('pf.recive_date', [$deliveryStart, $deliveryEnd]);
        }

        return $query;
    }

    public function scopeWithSalesReportOnlySales($query, $startDate = null, $endDate = null)
    {
        $query->select('products.*')
            ->addSelect(DB::raw('COUNT(DISTINCT pfi.pishfactor_id) as invoice_count'))
            ->addSelect(DB::raw('SUM((pfi.pack * products.pack_items) + pfi.tedad) as total_qty'))
            ->addSelect(DB::raw("
            SUM(
                (
                    ((pfi.pack * products.pack_items) + pfi.tedad)
                    * pfi.price
                )
                * (1 - (pfi.discount / 100))
                * (1 + (products.tax / 100))
            ) as total_amount
        "))
            ->leftJoin('pish_factor_items as pfi', 'products.id', '=', 'pfi.pr_id')
            ->leftJoin('pishfactors as pf', 'pfi.pishfactor_id', '=', 'pf.id')
            ->whereIn('pf.status', [1, 4])
            ->groupBy('products.id');

        // فیلتر تاریخ اگر داده شده باشد
        if ($startDate && $endDate) {
            $query->whereBetween('pf.created_at', [$startDate, $endDate]);
        }

        return $query;
    }








}
