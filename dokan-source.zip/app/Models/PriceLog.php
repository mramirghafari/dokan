<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class PriceLog extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['price','discount','tax','fee_masraf','price_from_fa','	price_exp_fa','price_from_en','price_exp_en','created_at','updated_at','deleted_at'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    
}
