<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Tenants extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['id','name','unit_order','sub_order','currency_type','tozihat','status','created_at','updated_at','deleted_at'];

    public function roles(){
        return $this->belongsToMany(Role::class);
    }
}
